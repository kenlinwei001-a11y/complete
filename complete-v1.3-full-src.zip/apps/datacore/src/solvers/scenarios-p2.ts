import { round } from "../prng.js";
import { validationError } from "../errors.js";
import { dayFrom, num, str, type SolverContext } from "./types.js";
import { computeRollup } from "./capacity.js";

// ---------------------------------------------------------------------------
// 20 场景目录 §2 · 第二阶段求解器（需新增对象类型，全部确定性）。
// 批次 A：物料/认证/换型域 —— cert_schedule(S07) / kit_readiness(S08) /
// lta_gap(S09) / inventory_optimize(S10) / changeover_sequence(S11)。
// 数值常量取自 solver_params.p2，求解器内仅留与种子一致的兜底。
// ---------------------------------------------------------------------------

const P2_DEFAULT = {
  certSchedule: { engineerGroups: 3, hoursPerWeek: 80 },
  kit: { stdCycleDays: 14 },
  inventory: { runRateDays: 180, overTargetMult: 1.5, underTargetMult: 0.8, dormantDays: 90 },
  lta: { poSplit: 2 },
  changeover: { freezeDays: 3 },
};

function p2(c: SolverContext) {
  return { ...P2_DEFAULT, ...(c.params.p2 ?? {}) } as typeof P2_DEFAULT;
}

function baseLabel(c: SolverContext, baseId: string): string {
  const b = c.bases.find((x) => x.props.baseId === baseId);
  return str(b?.props.name, baseId);
}

/** 该型号未来 horizonDays 内的订单需求合计（套）。 */
function modelDemand(c: SolverContext, modelId: string, horizonDays: number): number {
  return c.orders
    .filter((o) => str(o.props.model) === modelId && dayFrom(c.params.forecastStart, str(o.props.due)) <= horizonDays && dayFrom(c.params.forecastStart, str(o.props.due)) >= 0)
    .reduce((a, o) => a + num(o.props.qty), 0);
}

// ---------------------------------------------------------------------------
// S07 cert_schedule {horizonWeeks}
// 待认证集 = Certification status∈{认证中,待认证}；priority = 需求贡献/认证工时；
// 按 priority 降序，受 C26 并行认证 ≤ 工程师组数 约束并行装箱到周。
// ---------------------------------------------------------------------------

export interface CertScheduleArgs {
  horizonWeeks?: number;
}

const CERT_FACTOR: Record<string, number> = { 量产: 1.0, 认证中: 0.6, 待认证: 0.0 };

export function certSchedule(c: SolverContext, args: CertScheduleArgs): Record<string, unknown> {
  const cfg = p2(c).certSchedule;
  const horizonWeeks = Math.max(1, Math.floor(num(args.horizonWeeks, 12)));
  const horizonDays = horizonWeeks * 7;
  const rollup = computeRollup(c);
  const weeklyByBase = new Map(rollup.bases.map((b) => [b.baseId, b.weeklyWan]));

  const tasks = c.certifications
    .filter((cert) => ["认证中", "待认证"].includes(str(cert.props.status)))
    .map((cert) => {
      const modelId = str(cert.props.modelId);
      const baseId = str(cert.props.baseId);
      const status = str(cert.props.status);
      const certHours = Math.max(1, num(cert.props.certHours));
      const contribution = modelDemand(c, modelId, horizonDays);
      const unlockWeeklyWan = round((weeklyByBase.get(baseId) ?? 0) * (1.0 - (CERT_FACTOR[status] ?? 0)), 4);
      const priority = round(contribution / certHours, 6);
      const durWeeks = Math.max(1, Math.ceil(certHours / cfg.hoursPerWeek));
      return { certId: str(cert.props.certId), modelId, baseId, base: baseLabel(c, baseId), status, certHours, contribution, unlockWeeklyWan, priority, durWeeks };
    })
    .sort((a, b) => b.priority - a.priority || (a.certId < b.certId ? -1 : 1));

  // C26：engineerGroups 台并行机，每台空闲周从 1 起；取最早空闲机。
  const machineFree = new Array<number>(cfg.engineerGroups).fill(1);
  const schedule = tasks.map((t) => {
    let mi = 0;
    for (let i = 1; i < machineFree.length; i++) if ((machineFree[i] as number) < (machineFree[mi] as number)) mi = i;
    const startWeek = machineFree[mi] as number;
    const finishWeek = startWeek + t.durWeeks - 1;
    machineFree[mi] = finishWeek + 1;
    return {
      certId: t.certId,
      model: t.modelId,
      base: t.base,
      status: t.status,
      certHours: t.certHours,
      priority: t.priority,
      group: mi + 1,
      startWeek,
      finishWeek,
      unlockWeeklyWan: t.unlockWeeklyWan,
      withinHorizon: finishWeek <= horizonWeeks,
    };
  });

  return {
    horizonWeeks,
    engineerGroups: cfg.engineerGroups,
    schedule,
    overflow: schedule.filter((s) => !s.withinHorizon).map((s) => ({ certId: s.certId, finishWeek: s.finishWeek })),
    ruleRefs: ["C26"],
  };
}

// ---------------------------------------------------------------------------
// 物料可得性辅助（现库 + 在途）。
// ---------------------------------------------------------------------------

/** 某物料的现库(kg) + 在途批次（按 ETA）。可选限定基地集。 */
function materialAvail(c: SolverContext, materialId: string, baseIds?: Set<string>): { stockKg: number; inTransit: { etaDay: number; kg: number }[] } {
  let stockKg = 0;
  const inTransit: { etaDay: number; kg: number }[] = [];
  for (const b of c.materialBatches) {
    if (str(b.props.materialId) !== materialId) continue;
    if (baseIds && !baseIds.has(str(b.props.baseId))) continue;
    const kg = num(b.props.qtyTons) * 1000;
    if (str(b.props.status) === "IN_TRANSIT") inTransit.push({ etaDay: num(b.props.etaDay), kg });
    else stockKg += kg;
  }
  inTransit.sort((a, b) => a.etaDay - b.etaDay);
  return { stockKg, inTransit };
}

function materialById(c: SolverContext, materialId: string) {
  return c.materials.find((m) => str(m.props.materialId) === materialId);
}

// ---------------------------------------------------------------------------
// S08 kit_readiness {fromDay, toDay}
// 逐单 齐套率 = min_物料 (现库 + ETA≤开工日的在途) / (BOM单耗 × qty × packCells)；
// 开工日 = 交期 − 标准生产周期。
// ---------------------------------------------------------------------------

export interface KitReadinessArgs {
  fromDay?: number;
  toDay?: number;
}

export function kitReadiness(c: SolverContext, args: KitReadinessArgs): Record<string, unknown> {
  const cfg = p2(c).kit;
  const packCells = c.params.packCellCount;
  const from = num(args.fromDay, 1);
  const to = num(args.toDay, 14);
  const mats = c.materials;
  if (mats.length === 0) throw validationError("no Material objects seeded");

  const inWindow = c.orders
    .map((o) => ({ o, dueDay: dayFrom(c.params.forecastStart, str(o.props.due)) }))
    .filter((x) => x.dueDay >= from && x.dueDay <= to)
    .sort((a, b) => a.dueDay - b.dueDay || (str(a.o.props.so) < str(b.o.props.so) ? -1 : 1));

  const rows = inWindow.map(({ o, dueDay }) => {
    const qty = num(o.props.qty);
    const cells = qty * packCells;
    const startDay = dueDay - cfg.stdCycleDays;
    const bases = new Set(Array.isArray(o.props.bases) ? (o.props.bases as string[]) : []);
    let kitRatio = Infinity;
    const shortages: Record<string, unknown>[] = [];
    for (const m of mats) {
      const materialId = str(m.props.materialId);
      const need = num(m.props.bomPerCell) * cells; // kg
      if (need <= 0) continue;
      const { stockKg, inTransit } = materialAvail(c, materialId, bases.size > 0 ? bases : undefined);
      const arrivedInTransit = inTransit.filter((t) => t.etaDay <= startDay).reduce((a, t) => a + t.kg, 0);
      const avail = stockKg + arrivedInTransit;
      const ratio = round(avail / need, 4);
      kitRatio = Math.min(kitRatio, ratio);
      if (ratio < 1) {
        const earliest = inTransit.find((t) => t.etaDay > startDay)?.etaDay ?? startDay + num(m.props.leadTimeDays, 18);
        shortages.push({
          material: materialId,
          gapTons: round((need - avail) / 1000, 3),
          earliestReplenishDay: earliest,
        });
      }
    }
    if (!Number.isFinite(kitRatio)) kitRatio = 1;
    const advice =
      kitRatio >= 1 ? "齐套，可开工"
        : shortages.every((s) => num(s.earliestReplenishDay) <= startDay) ? "加急采购可补齐"
          : shortages.some((s) => num(s.earliestReplenishDay) <= dueDay) ? "调拨 / 加急采购，压缩到货间隙"
            : "顺延开工（到货晚于交期）";
    return {
      so: str(o.props.so),
      cust: str(o.props.cust),
      model: str(o.props.model),
      qty,
      due: str(o.props.due),
      dueDay,
      startDay,
      kitRatio,
      shortages,
      advice,
    };
  });

  return {
    fromDay: from,
    toDay: to,
    orders: rows,
    shortageCount: rows.filter((r) => (r.kitRatio as number) < 1).length,
    ruleRefs: ["C06", "C16"],
  };
}

// ---------------------------------------------------------------------------
// S09 lta_gap {material, month}
// 净需求 = Σ(月需求×BOM) − 现库 − 在途；长协可用 = 年锁量×月配额 − 已执行；
// 现货缺口 = max(0, 净需求 − 长协可用)。
// ---------------------------------------------------------------------------

export interface LtaGapArgs {
  material: string;
  month: string; // "2026-07"
}

export function ltaGap(c: SolverContext, args: LtaGapArgs): Record<string, unknown> {
  const materialId = str(args.material);
  const month = str(args.month);
  if (!/^\d{4}-\d{2}$/.test(month)) throw validationError(`invalid month '${month}' (expected e.g. 2026-07)`);
  const m = materialById(c, materialId);
  if (!m) throw validationError(`unknown material '${materialId}'`);
  const packCells = c.params.packCellCount;
  const bomPerCell = num(m.props.bomPerCell);

  // 月需求（kg）= Σ 当月交期订单 qty × packCells × BOM。
  const monthCells = c.orders
    .filter((o) => str(o.props.due).slice(0, 7) === month)
    .reduce((a, o) => a + num(o.props.qty) * packCells, 0);
  const monthDemandKg = round(monthCells * bomPerCell, 2);

  const { stockKg, inTransit } = materialAvail(c, materialId);
  const inTransitKg = inTransit.reduce((a, t) => a + t.kg, 0);
  const netDemandKg = round(Math.max(0, monthDemandKg - stockKg - inTransitKg), 2);

  // 年锁量 = 年化需求 × 锁量比；月配额 = 年锁量 / 12；已执行设 0（确定性，无时钟）。
  const annualDemandKg = monthDemandKg * 12;
  const annualLockKg = round(annualDemandKg * num(m.props.ltaLockRatio, 0.6), 2);
  const monthlyQuotaKg = round(annualLockKg / 12, 2);
  const executedKg = 0;
  const ltaAvailableKg = round(monthlyQuotaKg - executedKg, 2);

  const spotGapKg = round(Math.max(0, netDemandKg - ltaAvailableKg), 2);
  const coverage = monthDemandKg > 0 ? round(Math.min(1, (ltaAvailableKg + stockKg + inTransitKg) / monthDemandKg), 4) : 1;

  const poSplit = p2(c).lta.poSplit;
  const demandDay = Date.parse(`${month}-01T00:00:00Z`);
  const latestOrderDay = new Date(demandDay - num(m.props.leadTimeDays, 18) * 86400000).toISOString().slice(0, 10);
  const suggestedPOs = spotGapKg > 0
    ? Array.from({ length: poSplit }, (_, i) => ({
        batch: i + 1,
        qtyTons: round(spotGapKg / poSplit / 1000, 3),
        latestOrderDate: latestOrderDay,
      }))
    : [];

  return {
    material: materialId,
    month,
    monthDemandTons: round(monthDemandKg / 1000, 3),
    stockTons: round(stockKg / 1000, 3),
    inTransitTons: round(inTransitKg / 1000, 3),
    netDemandTons: round(netDemandKg / 1000, 3),
    ltaAvailableTons: round(ltaAvailableKg / 1000, 3),
    monthlyQuotaTons: round(monthlyQuotaKg / 1000, 3),
    spotGapTons: round(spotGapKg / 1000, 3),
    coverage,
    suggestedPOs,
    ruleRefs: ["C16", "C27"],
  };
}

// ---------------------------------------------------------------------------
// S10 inventory_optimize {}
// 目标水位 = 日均耗用 ×(采购交期 + 安全天数)；超储 = max(0, 现库 − 1.5×目标)；
// 欠储 = max(0, 0.8×目标 − 现库)；可释放资金 = Σ超储×单价；呆滞 = ≥90 日无耗用批次。
// ---------------------------------------------------------------------------

export function inventoryOptimize(c: SolverContext): Record<string, unknown> {
  const cfg = p2(c).inventory;
  const packCells = c.params.packCellCount;
  // 全订单需求（套）→ 日均耗用按 runRateDays 摊（与产销窗口同口径）。
  const totalCells = c.orders.reduce((a, o) => a + num(o.props.qty), 0) * packCells;

  const over: Record<string, unknown>[] = [];
  const under: Record<string, unknown>[] = [];
  const dormant: Record<string, unknown>[] = [];
  let releasableYuan = 0;

  for (const m of c.materials) {
    const materialId = str(m.props.materialId);
    const unitPrice = num(m.props.unitPrice); // 元/kg
    const dailyUseKg = round((totalCells * num(m.props.bomPerCell)) / cfg.runRateDays, 3);
    const targetKg = round(dailyUseKg * (num(m.props.leadTimeDays, 18) + num(m.props.safetyDays, 5)), 3);
    const { stockKg } = materialAvail(c, materialId);

    const overKg = round(Math.max(0, stockKg - cfg.overTargetMult * targetKg), 3);
    const underKg = round(Math.max(0, cfg.underTargetMult * targetKg - stockKg), 3);
    if (overKg > 0) {
      const cash = round(overKg * unitPrice, 2);
      releasableYuan += cash;
      over.push({ material: materialId, stockTons: round(stockKg / 1000, 3), targetTons: round(targetKg / 1000, 3), overTons: round(overKg / 1000, 3), releasableYuan: cash });
    }
    if (underKg > 0) {
      under.push({ material: materialId, stockTons: round(stockKg / 1000, 3), targetTons: round(targetKg / 1000, 3), underTons: round(underKg / 1000, 3) });
    }
  }

  for (const b of c.materialBatches) {
    if (num(b.props.lastConsumedDays) >= cfg.dormantDays || num(b.props.ageDays) >= cfg.dormantDays) {
      dormant.push({
        batchId: str(b.props.batchId),
        material: str(b.props.materialId),
        base: baseLabel(c, str(b.props.baseId)),
        ageDays: num(b.props.ageDays),
        lastConsumedDays: num(b.props.lastConsumedDays),
        qtyTons: num(b.props.qtyTons),
      });
    }
  }
  dormant.sort((a, b) => (str(a.batchId) < str(b.batchId) ? -1 : 1));

  return {
    overStock: over.sort((a, b) => num(b.releasableYuan) - num(a.releasableYuan)),
    underStock: under,
    dormant,
    releasableYuan: round(releasableYuan, 2),
    releasableYi: round(releasableYuan / 1e8, 4),
    ruleRefs: ["C16", "C28"],
  };
}

// ---------------------------------------------------------------------------
// S11 changeover_sequence {lineId, week}
// 该线周订单集 + 换型矩阵；最近邻贪心（从首单型号起，每步选 M 最小未排单）；
// vs 交期序节省；标注违反交期的单（冻结期 C29）。
// ---------------------------------------------------------------------------

export interface ChangeoverSequenceArgs {
  lineId: string;
  week?: number;
}

function resolveLineBase(c: SolverContext, ref: string): string {
  const l = c.lines.find((x) => str(x.props.lineId) === ref || str(x.props.name) === ref);
  if (l) return str(l.props.baseId);
  // 兼容 "常州·动力线-A" 形态：取基地名前缀。
  const b = c.bases.find((x) => ref.startsWith(str(x.props.name)));
  if (b) return str(b.props.baseId);
  throw validationError(`unknown line '${ref}'`);
}

function changeoverMinutes(c: SolverContext, from: string, to: string): number {
  if (from === to) return 0;
  const cm = c.changeovers.find((x) => str(x.props.fromModel) === from && str(x.props.toModel) === to);
  return cm ? num(cm.props.minutes) : 0;
}

export function changeoverSequence(c: SolverContext, args: ChangeoverSequenceArgs): Record<string, unknown> {
  const lineRef = str(args.lineId);
  if (!lineRef) throw validationError("lineId required");
  const baseId = resolveLineBase(c, lineRef);
  const week = Math.max(1, Math.floor(num(args.week, 1)));
  const fromDay = (week - 1) * 7;
  const toDay = week * 7;

  const pool = c.orders
    .filter((o) => {
      const bases = Array.isArray(o.props.bases) ? (o.props.bases as string[]) : [];
      const dueDay = dayFrom(c.params.forecastStart, str(o.props.due));
      return bases.includes(baseId) && dueDay > fromDay && dueDay <= toDay;
    })
    .map((o) => ({ so: str(o.props.so), model: str(o.props.model), dueDay: dayFrom(c.params.forecastStart, str(o.props.due)), qty: num(o.props.qty) }));

  if (pool.length === 0) {
    return { lineId: lineRef, baseId, week, sequence: [], totalChangeoverMin: 0, dueSeqChangeoverMin: 0, savedMin: 0, dueViolations: [], ruleRefs: ["C22", "C29"] };
  }

  // 交期序（基线）。
  const dueSeq = [...pool].sort((a, b) => a.dueDay - b.dueDay || (a.so < b.so ? -1 : 1));
  const seqTime = (seq: typeof pool) => {
    let t = 0;
    for (let i = 1; i < seq.length; i++) t += changeoverMinutes(c, seq[i - 1]!.model, seq[i]!.model);
    return t;
  };
  const dueSeqMin = seqTime(dueSeq);

  // 最近邻贪心：从交期最早单起，每步选换型最小的未排单。
  const remaining = [...pool].sort((a, b) => a.dueDay - b.dueDay || (a.so < b.so ? -1 : 1));
  const greedy: typeof pool = [remaining.shift() as typeof pool[number]];
  while (remaining.length > 0) {
    const cur = greedy[greedy.length - 1]!.model;
    remaining.sort((a, b) => {
      const ma = changeoverMinutes(c, cur, a.model);
      const mb = changeoverMinutes(c, cur, b.model);
      return ma - mb || a.dueDay - b.dueDay || (a.so < b.so ? -1 : 1);
    });
    greedy.push(remaining.shift() as typeof pool[number]);
  }
  const greedyMin = seqTime(greedy);

  // 违反交期：贪心序中某单排在交期更晚的单之后（被顺延越过交期序）。
  const dueViolations: Record<string, unknown>[] = [];
  let maxDueSoFar = -Infinity;
  greedy.forEach((o, idx) => {
    if (o.dueDay < maxDueSoFar) dueViolations.push({ so: o.so, model: o.model, dueDay: o.dueDay, position: idx + 1, note: "贪心序将其排在更晚交期单之后，存在交期风险，需人工确认" });
    maxDueSoFar = Math.max(maxDueSoFar, o.dueDay);
  });

  return {
    lineId: lineRef,
    baseId,
    week,
    sequence: greedy.map((o, i) => ({ position: i + 1, so: o.so, model: o.model, dueDay: o.dueDay, changeoverFromPrevMin: i === 0 ? 0 : changeoverMinutes(c, greedy[i - 1]!.model, o.model) })),
    totalChangeoverMin: greedyMin,
    dueSeqChangeoverMin: dueSeqMin,
    savedMin: round(dueSeqMin - greedyMin, 2),
    dueViolations,
    ruleRefs: ["C22", "C29"],
  };
}
