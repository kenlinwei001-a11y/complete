import { round, hashString } from "../prng.js";
import { validationError } from "../errors.js";
import { num, str, type SolverContext } from "./types.js";

// ---------------------------------------------------------------------------
// 20 场景目录 §2 · 第二阶段批次 B（客户/财务/碳/良率域）。
// quote_margin(S15) / credit_exposure(S16) / carbon_footprint(S20) / yield_diagnosis(S12)。
// 全部确定性；数值常量取自 solver_params.p2，求解器内仅留与种子一致的兜底。
// ---------------------------------------------------------------------------

const P2B_DEFAULT = {
  quote: { manufCostRate: 0.12, logisticsCostRate: 0.015, processFeeRate: 0.08, targetMarginSpread: 0.06 },
  credit: { overdueLimitDays: 30 },
  carbon: { euThresholdKg: 14.8 },
  yield: { window: 30, sigmaK: 2, dropBaselinePct: 0.02 },
};

function cfg<K extends keyof typeof P2B_DEFAULT>(c: SolverContext, k: K): (typeof P2B_DEFAULT)[K] {
  return { ...P2B_DEFAULT[k], ...((c.params.p2?.[k] as object) ?? {}) } as (typeof P2B_DEFAULT)[K];
}

function chemistryOf(modelId: string): string {
  return modelId.includes("LFP") ? "LFP" : "NCM";
}

/** 该型号化学体系相关的物料（剔除另一体系的正极）。 */
function modelMaterials(c: SolverContext, modelId: string) {
  const chem = chemistryOf(modelId);
  return c.materials.filter((m) => {
    const cat = str(m.props.category);
    const id = str(m.props.materialId);
    if (cat === "正极") return chem === "LFP" ? id.includes("铁锂") : id.includes("三元");
    return true;
  });
}

function customerByName(c: SolverContext, name: string) {
  return c.customers.find((x) => str(x.props.name) === name);
}

function segmentFloorOf(c: SolverContext, modelId: string): { seg: string; floor: number } {
  const pr = c.params.affected.problems;
  const key = pr.essModels.includes(modelId) ? "ess" : pr.comModels.includes(modelId) ? "com" : "pas";
  const floorPct = c.params.audit.segMargins[key as "pas" | "ess" | "com"];
  return { seg: key, floor: round(floorPct / 100, 4) };
}

// ---------------------------------------------------------------------------
// S15 quote_margin {orderId | (custName, modelId, qty, price)}
// BOM = Σ(单耗×packCells×大宗现价×(1+加工费率))；制造/物流费按 BOM 比率；
// 报价 = 成本/(1−目标毛利) ×(1−客户折扣)；毛利率 = (价−成本)/价，对比细分底线 C15。
// ---------------------------------------------------------------------------

export interface QuoteMarginArgs {
  orderId?: string;
  custName?: string;
  modelId?: string;
  qty?: number;
}

export function quoteMargin(c: SolverContext, args: QuoteMarginArgs): Record<string, unknown> {
  const q = cfg(c, "quote");
  const packCells = c.params.packCellCount;

  let modelId = str(args.modelId);
  let custName = str(args.custName);
  let qty = num(args.qty);
  if (args.orderId) {
    const o = c.orders.find((x) => str(x.props.so) === str(args.orderId));
    if (!o) throw validationError(`unknown order '${args.orderId}'`);
    modelId = str(o.props.model);
    custName = str(o.props.cust);
    qty = num(o.props.qty);
  }
  if (!modelId) throw validationError("modelId (or orderId) required");

  const mats = modelMaterials(c, modelId);
  if (mats.length === 0) throw validationError("no Material objects seeded");
  const bomItems = mats.map((m) => {
    const perUnit = round(num(m.props.bomPerCell) * packCells * num(m.props.unitPrice) * (1 + q.processFeeRate), 2);
    return { material: str(m.props.materialId), bomCost: perUnit };
  });
  const bom = round(bomItems.reduce((a, x) => a + x.bomCost, 0), 2);
  const manuf = round(bom * q.manufCostRate, 2);
  const logistics = round(bom * q.logisticsCostRate, 2);
  const cost = round(bom + manuf + logistics, 2);

  const { seg, floor } = segmentFloorOf(c, modelId);
  const targetGM = round(floor + q.targetMarginSpread, 4);
  const listPrice = round(cost / (1 - targetGM), 2);
  // 客户折扣：来自 Customer.discountRate（无客户取 0）。
  const discount = num(customerByName(c, custName)?.props.discountRate, 0);
  const price = round(listPrice * (1 - discount), 2);
  const margin = round((price - cost) / price, 4);

  const verdict = margin >= floor ? "过线" : margin >= floor - 0.01 ? "触线" : "低于底线";

  return {
    modelId,
    custName,
    qty,
    segment: seg,
    breakdown: { bom, manuf, logistics, cost, listPrice, discount, price, bomItems },
    margin,
    marginPct: round(margin * 100, 2),
    floor,
    floorPct: round(floor * 100, 2),
    diffPct: round((margin - floor) * 100, 2),
    verdict,
    ruleRefs: ["C15", "C24"],
  };
}

// ---------------------------------------------------------------------------
// S16 credit_exposure {custName, newOrderAmount?}
// 敞口 = 在手应收 + 在产未开票订单金额；可用 = 信用额度 − 敞口；
// 逾期 = 应收 overdueDays > 30(C32)；判定 = 新单 ≤ 可用 ∧ 无逾期。
// ---------------------------------------------------------------------------

export interface CreditExposureArgs {
  custName: string;
  newOrderAmount?: number;
}

export function creditExposure(c: SolverContext, args: CreditExposureArgs): Record<string, unknown> {
  const custName = str(args.custName);
  if (!custName) throw validationError("custName required");
  const cust = customerByName(c, custName);
  if (!cust) throw validationError(`unknown customer '${custName}'`);
  const overdueLimit = cfg(c, "credit").overdueLimitDays;
  const creditLimit = num(cust.props.creditLimit);

  const invoices = c.arInvoices.filter((i) => str(i.props.custName) === custName);
  const arOutstanding = round(invoices.filter((i) => str(i.props.status) === "OPEN").reduce((a, i) => a + num(i.props.amount), 0), 2);
  const inProduction = round(
    c.orders.filter((o) => str(o.props.cust) === custName).reduce((a, o) => a + num(o.props.qty) * num(o.props.unitPrice), 0),
    2,
  );
  const exposure = round(arOutstanding + inProduction, 2);
  const available = round(creditLimit - exposure, 2);

  const overdueList = invoices
    .filter((i) => num(i.props.overdueDays) > overdueLimit)
    .map((i) => ({ invId: str(i.props.invId), amount: num(i.props.amount), dueDate: str(i.props.dueDate), overdueDays: num(i.props.overdueDays) }))
    .sort((a, b) => b.overdueDays - a.overdueDays);

  const newOrderAmount = num(args.newOrderAmount, 0);
  const frozen = overdueList.length > 0; // C32 逾期冻结优先于额度判断
  const withinLimit = newOrderAmount <= available;
  const verdict = frozen
    ? "冻结（存在逾期，C32 优先）"
    : newOrderAmount > 0
      ? withinLimit ? "可接（额度充足）" : "超限（新单超过可用额度）"
      : available > 0 ? "额度可用" : "额度已用尽";

  return {
    custName,
    creditLimit,
    exposure,
    exposureBreakdown: { arOutstanding, inProduction },
    available,
    overdueList,
    newOrderAmount,
    frozen,
    withinLimit,
    verdict,
    ruleRefs: ["C13", "C32"],
  };
}

// ---------------------------------------------------------------------------
// S20 carbon_footprint {modelId, baseName}
// 碳足迹/电芯 = Σ(物料单耗×物料碳因子) + 单位能耗×电网因子(基地省)；对比欧盟阈值。
// ---------------------------------------------------------------------------

export interface CarbonFootprintArgs {
  modelId: string;
  baseName?: string;
  baseId?: string;
}

export function carbonFootprint(c: SolverContext, args: CarbonFootprintArgs): Record<string, unknown> {
  const modelId = str(args.modelId);
  if (!modelId) throw validationError("modelId required");
  const ref = str(args.baseId) || str(args.baseName);
  const base = ref
    ? c.bases.find((b) => str(b.props.baseId) === ref || str(b.props.name) === ref)
    : c.bases[0];
  if (!base) throw validationError(`unknown base '${ref}'`);
  const province = str(base.props.province);
  const grid = c.carbonFactors.find((f) => str(f.props.kind) === "grid" && str(f.props.refKey) === province);
  const gridFactor = num(grid?.props.factor, 0.6);

  const mats = modelMaterials(c, modelId);
  const materialItems = mats.map((m) => {
    const kg = round(num(m.props.bomPerCell) * num(m.props.carbonFactor), 4);
    return { material: str(m.props.materialId), bomPerCell: num(m.props.bomPerCell), carbonFactor: num(m.props.carbonFactor), kgCO2e: kg };
  });
  const materialCarbon = round(materialItems.reduce((a, x) => a + x.kgCO2e, 0), 4);
  const energyKwhPerCell = num(base.props.energyKwhPerCell);
  const energyCarbon = round(energyKwhPerCell * gridFactor, 4);
  const total = round(materialCarbon + energyCarbon, 4);

  const threshold = cfg(c, "carbon").euThresholdKg;
  const verdict = total <= threshold ? "达标" : "超标";
  const overPct = round(((total - threshold) / threshold) * 100, 2);

  // 最大改善杠杆 = 分解中最大单项（物料或能耗）。
  const levers = [...materialItems.map((x) => ({ item: x.material, kind: "material", kgCO2e: x.kgCO2e })), { item: `${str(base.props.name)}电网能耗`, kind: "energy", kgCO2e: energyCarbon }];
  levers.sort((a, b) => b.kgCO2e - a.kgCO2e);

  return {
    modelId,
    base: str(base.props.name),
    province,
    gridFactor,
    materialCarbon,
    energyCarbon,
    total,
    threshold,
    verdict,
    overPct,
    materialItems,
    maxLever: levers[0],
    ruleRefs: ["C33"],
  };
}

// ---------------------------------------------------------------------------
// S12 yield_diagnosis {processKey, baseName, window=30}
// 良率时序滑窗突变检测：突变点 = 首个 |后7日均值−前7日均值| > sigmaK×σ(前window日) 的日；
// 候选根因 = 突变点 ±2 日内事件对象（来料批次切换 / 检修 / 换批）。
// 因果植入：涂布×常州 在窗口中段 −dropBaselinePct（与 §7 yield_drop 剧本同源）。
// ---------------------------------------------------------------------------

export interface YieldDiagnosisArgs {
  processKey: string;
  baseName?: string;
  baseId?: string;
  window?: number;
}

/** 确定性良率日序：基线 + 小幅确定性噪声；植入基地/工序在 dropDay 起阶跃下降。 */
function yieldSeries(c: SolverContext, baseId: string, processKey: string, baseline: number, window: number, dropPct: number): { series: number[]; dropDay: number | null } {
  const len = window * 2;
  // 仅 涂布 × 常州 植入阶跃（§7 剧本）；其余无突变。
  const planted = processKey.includes("涂布") && baseId === "changzhou";
  const dropDay = planted ? window : null;
  const series: number[] = [];
  for (let d = 1; d <= len; d++) {
    const noise = ((hashString(`${baseId}|${processKey}|${d}`) % 7) - 3) / 1000; // ±0.003 确定性
    let v = baseline + noise;
    if (dropDay !== null && d >= dropDay) v -= dropPct;
    series.push(round(Math.max(0, v), 4));
  }
  return { series, dropDay };
}

export function yieldDiagnosis(c: SolverContext, args: YieldDiagnosisArgs): Record<string, unknown> {
  const processKey = str(args.processKey);
  if (!processKey) throw validationError("processKey required");
  const ref = str(args.baseId) || str(args.baseName);
  const base = ref ? c.bases.find((b) => str(b.props.baseId) === ref || str(b.props.name) === ref) : c.bases[0];
  if (!base) throw validationError(`unknown base '${ref}'`);
  const baseId = str(base.props.baseId);
  const yc = cfg(c, "yield");
  const window = Math.max(14, Math.floor(num(args.window, yc.window)));

  // 工序良率基线（该基地匹配 processKey 的工序）。
  const proc = c.processes.find((p) => p.props.baseId === baseId && str(p.props.name).includes(processKey));
  const baseline = num(proc?.props.yield, 0.96);
  const { series, dropDay } = yieldSeries(c, baseId, processKey, baseline, window, yc.dropBaselinePct);

  // σ（前 window 日）。
  const head = series.slice(0, window);
  const mean = head.reduce((a, v) => a + v, 0) / head.length;
  const sigma = Math.sqrt(head.reduce((a, v) => a + (v - mean) ** 2, 0) / head.length);
  const threshold = yc.sigmaK * sigma;

  // 滑窗：首个 |后7均 − 前7均| > threshold 的日。
  let changeDay: number | null = null;
  let dropMagnitude = 0;
  for (let i = 7; i + 7 <= series.length; i++) {
    const prev = series.slice(i - 7, i).reduce((a, v) => a + v, 0) / 7;
    const next = series.slice(i, i + 7).reduce((a, v) => a + v, 0) / 7;
    if (Math.abs(next - prev) > threshold) {
      changeDay = i + 1; // 1-based 突变日
      dropMagnitude = round(prev - next, 4);
      break;
    }
  }

  // 候选根因：突变日 ±2 内的事件对象。
  const candidates: Record<string, unknown>[] = [];
  if (changeDay !== null) {
    for (const b of c.materialBatches) {
      if (str(b.props.baseId) !== baseId || str(b.props.status) !== "IN_TRANSIT") continue;
      const dist = Math.abs(num(b.props.etaDay) - changeDay);
      if (dist <= 2) candidates.push({ event: `来料批次切换 ${str(b.props.batchId)}（${str(b.props.materialId)}）`, source: "MaterialBatch", distanceDays: dist });
    }
    const mp = c.maintPlans.find((m) => str(m.props.baseId) === baseId);
    if (mp) {
      const dist = Math.abs(num(mp.props.week) * 7 - changeDay);
      if (dist <= 2) candidates.push({ event: `检修窗口（第 ${num(mp.props.week)} 周）`, source: "MaintPlan", distanceDays: dist });
    }
    // 换批/换型通用事件（与突变同日，剧本根因）。
    candidates.push({ event: `${processKey}换批参数切换`, source: "ProcessEvent", distanceDays: 0 });
    candidates.sort((a, b) => num(a.distanceDays) - num(b.distanceDays));
  }

  return {
    processKey,
    base: str(base.props.name),
    baseId,
    baseline: round(baseline, 4),
    window,
    sigma: round(sigma, 5),
    detectionThreshold: round(threshold, 5),
    changeDay,
    dropMagnitude,
    dropPct: round(dropMagnitude * 100, 2),
    sustainTrigger: dropMagnitude >= yc.dropBaselinePct, // C30 评审触发（连降 ≥ 基线降幅阈，默认 2pct）
    candidates,
    plantedDrop: dropDay !== null,
    ruleRefs: ["C30"],
  };
}
