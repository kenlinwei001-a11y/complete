import { round } from "../prng.js";
import { validationError } from "../errors.js";
import { dayFrom, num, str, type SolverContext } from "./types.js";
import { mockTightness } from "./risk.js";
import { computeRollup, curveMult } from "./capacity.js";

// ---------------------------------------------------------------------------
// 20 场景目录 §2 · 第一阶段求解器（无需新增对象类型，全部确定性）。
// 数值常量一律取自 solver_params（场景包种子的 BATTERY_SOLVER_PARAMS 默认值），
// 求解器代码内只保留与种子一致的兜底常量 —— 同输入 + 同参数版本 → 同输出。
// ---------------------------------------------------------------------------

/** 中文成本档 → 成本秩（低/中/高/极高 = 1/2/3/4），PRD §2 mitigation_select。 */
const DEFAULT_COST_RANK: Record<string, number> = { 低: 1, 中: 2, 高: 3, 极高: 4 };

function resolveBaseId(c: SolverContext, ref: string): string {
  const b = c.bases.find((x) => x.props.baseId === ref || x.props.name === ref);
  if (!b) throw validationError(`unknown base: ${ref}`);
  return str(b.props.baseId);
}

function baseLabel(c: SolverContext, baseId: string): string {
  const b = c.bases.find((x) => x.props.baseId === baseId);
  return str(b?.props.name, baseId);
}

// ---------------------------------------------------------------------------
// S06 mitigation_select — 入参 {baseName, factor}
// score_i = eff_i × urgency / (cost_rank_i × t_days_i)，urgency = max(0,(紧张度−70)/30)
// ---------------------------------------------------------------------------

export interface MitigationSelectArgs {
  baseName?: string;
  baseId?: string;
  factor: string;
}

export function mitigationSelect(c: SolverContext, args: MitigationSelectArgs): Record<string, unknown> {
  const ref = str(args.baseId) || str(args.baseName);
  if (!ref) throw validationError("baseName (or baseId) required");
  const factor = str(args.factor);
  if (!factor) throw validationError("factor required");
  const baseId = resolveBaseId(c, ref);

  const cfg = c.params.mitigationSelect;
  const costRank = cfg?.costRank ?? DEFAULT_COST_RANK;
  const urgencyBase = cfg?.urgencyBase ?? 70;
  const urgencyDen = cfg?.urgencyDen ?? 30;

  const tightness = mockTightness(c, baseId, factor);
  const urgency = round(Math.max(0, (tightness - urgencyBase) / urgencyDen), 4);

  const plans = c.params.risk.mitigations[factor] ?? [];
  if (plans.length === 0) throw validationError(`no mitigation plans registered for factor '${factor}'`);

  const options = plans
    .map((pl) => {
      const rank = costRank[pl.cost] ?? 2;
      const tDays = Math.max(1, pl.tn);
      // urgency=0（紧张度未越 70 阈）时 score 归零，退化为效费比 eff/(rank×tn) 作稳定排序键。
      const score = round((pl.eff * urgency) / (rank * tDays), 6);
      const costEff = round(pl.eff / (rank * tDays), 6);
      return { planKey: pl.key, name: pl.name, eff: pl.eff, tn: pl.tn, cost: pl.cost, costRank: rank, risk: pl.risk, score, costEff };
    })
    .sort((a, b) => b.score - a.score || b.costEff - a.costEff || (a.planKey < b.planKey ? -1 : 1));

  const recommended = options[0];
  const draftPayload = recommended
    ? {
        baseId,
        baseName: baseLabel(c, baseId),
        factor,
        planKey: recommended.planKey,
        planName: recommended.name,
        eff: recommended.eff,
        effectiveFrom: recommended.tn,
        tightness,
        expectedRelief: recommended.eff,
      }
    : undefined;

  return {
    baseId,
    baseName: baseLabel(c, baseId),
    factor,
    tightness,
    urgency,
    options,
    recommended: recommended?.planKey ?? "",
    draftPayload,
  };
}

// ---------------------------------------------------------------------------
// S14 outsourcing_split — 入参 {gap, weeks, totalDemand?}
// 三渠道：加班 c1=1.0 上限 gap×0.4；外协 c2=1.4 上限 总需求×20%(C08)；延期罚 c3=2.5。
// 按单位成本升序贪心分配，余量落延期罚。
// ---------------------------------------------------------------------------

export interface OutsourcingSplitArgs {
  gap: number;
  weeks?: number;
  /** 外协上限基数（总需求）。缺省回落为 gap —— 调用方不知总需求时按缺口的 20% 限外协。 */
  totalDemand?: number;
}

export function outsourcingSplit(c: SolverContext, args: OutsourcingSplitArgs): Record<string, unknown> {
  const gap = num(args.gap);
  if (gap <= 0) throw validationError("gap must be > 0");
  const weeks = Math.max(1, Math.floor(num(args.weeks, 6)));
  const totalDemand = num(args.totalDemand, gap);

  const cfg = c.params.outsourcing;
  const c1 = cfg?.overtimeCostPer ?? 1.0;
  const c2 = cfg?.outsourceCostPer ?? 1.4;
  const c3 = cfg?.delayPenaltyPer ?? 2.5;
  const overtimeCapRatio = cfg?.overtimeCapRatio ?? 0.4;
  const outsourceMax = c.params.whatIf.outsourceMax; // C08 红线

  const overtimeCap = round(gap * overtimeCapRatio, 4);
  const outsourceCap = round(totalDemand * outsourceMax, 4); // C08

  // 单位成本升序：加班(c1) → 外协(c2) → 延期罚(c3)。延期罚无上限（吸收残余）。
  const channels = [
    { key: "overtime", name: "自产加班", unitCost: c1, cap: overtimeCap, rule: undefined as string | undefined, note: undefined as string | undefined },
    { key: "outsource", name: "外协", unitCost: c2, cap: outsourceCap, rule: "C08", note: `外协量受 C08 红线封顶（总需求 ${round(totalDemand, 2)} × ${round(outsourceMax * 100, 0)}%）；外协部分须满足 C31 质量门（外协厂良率 ≥ 自产良率 − 2pct）` },
    { key: "delay", name: "延期交付（罚）", unitCost: c3, cap: Infinity, rule: undefined as string | undefined, note: "余量顺延，按延期罚成本计入" },
  ].sort((a, b) => a.unitCost - b.unitCost);

  let remaining = gap;
  const allocations = channels.map((ch) => {
    const qty = round(Math.min(remaining, ch.cap), 4);
    remaining = round(remaining - qty, 4);
    return { channel: ch.key, name: ch.name, qty, unitCost: ch.unitCost, cost: round(qty * ch.unitCost, 4), ...(ch.rule ? { rule: ch.rule } : {}), ...(ch.note ? { note: ch.note } : {}) };
  });

  const totalCost = round(allocations.reduce((a, x) => a + x.cost, 0), 4);
  const allDelayCost = round(gap * c3, 4);
  const savings = round(allDelayCost - totalCost, 4);

  return {
    gap,
    weeks,
    totalDemand,
    allocations,
    totalCost,
    allDelayCost,
    savings,
    c08OutsourceCap: outsourceCap,
    outsourceMax,
  };
}

// ---------------------------------------------------------------------------
// S13 maintenance_stagger — 入参 {}
// 冲突 = 检修周 ∈ 交付高峰周(top3)。对每冲突基地在 ±4 周窗内选新周 = argmin(当周交付负荷)，
// 约束：与上次检修间隔 ≥ minIntervalWeeks、同集团同周检修基地 ≤ sameGroupSameWeekMax。
// ---------------------------------------------------------------------------

export function maintenanceStagger(c: SolverContext): Record<string, unknown> {
  const p = c.params;
  const cfg = p.maintenanceStagger;
  const windowWeeks = cfg?.windowWeeks ?? 4;
  const minIntervalWeeks = cfg?.minIntervalWeeks ?? 8;
  const sameGroupSameWeekMax = cfg?.sameGroupSameWeekMax ?? 3;
  const topPeakWeeks = cfg?.topPeakWeeks ?? 3;
  const t0 = Date.parse(`${p.forecastStart.slice(0, 10)}T00:00:00Z`);

  // 交付负荷：按订单交期所在周聚合 qty（全基地）。
  const weekLoad = new Map<number, number>();
  for (const o of c.orders) {
    const dueDay = dayFrom(p.forecastStart, str(o.props.due));
    if (dueDay < 0) continue;
    const w = Math.floor(dueDay / 7) + 1;
    weekLoad.set(w, (weekLoad.get(w) ?? 0) + num(o.props.qty));
  }
  const loadOf = (w: number) => weekLoad.get(w) ?? 0;
  // 交付高峰周 = 负荷最高的 top3 周。
  const peakWeeks = new Set(
    [...weekLoad.entries()]
      .sort((a, b) => b[1] - a[1] || a[0] - b[0])
      .slice(0, topPeakWeeks)
      .map(([w]) => w),
  );

  const groupOf = (baseId: string): string => {
    const b = c.bases.find((x) => x.props.baseId === baseId);
    return str(b?.props.group) || str(b?.props.kind) || "默认集团";
  };

  // 现检修周占用（同集团同周计数，含未冲突基地——错峰后不得越上限）。
  const occupancy = new Map<string, number>(); // `${group}|${week}` → count
  const occKey = (group: string, week: number) => `${group}|${week}`;
  const plans = [...c.maintPlans].sort((a, b) => (str(a.props.planId) < str(b.props.planId) ? -1 : 1));
  for (const mp of plans) {
    const g = groupOf(str(mp.props.baseId));
    const w = num(mp.props.week);
    occupancy.set(occKey(g, w), (occupancy.get(occKey(g, w)) ?? 0) + 1);
  }

  const adjustments: Record<string, unknown>[] = [];
  const unresolved: Record<string, unknown>[] = [];

  for (const mp of plans) {
    const baseId = str(mp.props.baseId);
    const origWeek = num(mp.props.week);
    if (!peakWeeks.has(origWeek)) continue; // 非冲突

    const group = groupOf(baseId);
    // 上次检修相对周（lastMaintStart 相对 forecastStart 的周序，通常为负）。
    const lastMaintRelWeek = mp.props.lastMaintStart
      ? Math.round((Date.parse(`${str(mp.props.lastMaintStart).slice(0, 10)}T00:00:00Z`) - t0) / (7 * 86400000))
      : origWeek - 12;

    // 释放原占用后再择新周（基地自身的那一格腾出）。
    occupancy.set(occKey(group, origWeek), Math.max(0, (occupancy.get(occKey(group, origWeek)) ?? 1) - 1));

    const candidates: { week: number; load: number }[] = [];
    for (let w = Math.max(1, origWeek - windowWeeks); w <= origWeek + windowWeeks; w++) {
      if (w === origWeek) continue;
      if (peakWeeks.has(w)) continue; // 不可挪进另一交付高峰周
      if (w - lastMaintRelWeek < minIntervalWeeks) continue; // 与上次检修间隔约束
      if ((occupancy.get(occKey(group, w)) ?? 0) >= sameGroupSameWeekMax) continue; // 同集团同周上限
      candidates.push({ week: w, load: loadOf(w) });
    }
    candidates.sort((a, b) => a.load - b.load || a.week - b.week);

    const picked = candidates[0];
    if (!picked) {
      // 无可行周 → 不可解冲突，原占用恢复。
      occupancy.set(occKey(group, origWeek), (occupancy.get(occKey(group, origWeek)) ?? 0) + 1);
      unresolved.push({
        base: baseLabel(c, baseId),
        baseId,
        origWeek,
        reason: `±${windowWeeks} 周窗内无满足约束（间隔 ≥${minIntervalWeeks} 周 / 同集团同周 ≤${sameGroupSameWeekMax}）的非高峰周`,
      });
      continue;
    }
    occupancy.set(occKey(group, picked.week), (occupancy.get(occKey(group, picked.week)) ?? 0) + 1);
    adjustments.push({
      base: baseLabel(c, baseId),
      baseId,
      group,
      origWeek,
      suggestedWeek: picked.week,
      origLoad: round(loadOf(origWeek), 2),
      newLoad: round(picked.load, 2),
      loadDrop: round(loadOf(origWeek) - picked.load, 2),
    });
  }

  adjustments.sort((a, b) => num(b.loadDrop) - num(a.loadDrop) || (str(a.baseId) < str(b.baseId) ? -1 : 1));
  return {
    peakWeeks: [...peakWeeks].sort((a, b) => a - b),
    topPeakWeeks,
    windowWeeks,
    minIntervalWeeks,
    sameGroupSameWeekMax,
    adjustments,
    unresolved,
  };
}

// ---------------------------------------------------------------------------
// S19 quarterly_gap — 入参 {quarter}
// 缺口 = 季度滚动 gap（供给 = 周产能×认证×周曲线 13 周聚合；需求 = PlanTarget 季度目标×(1+滚动修正)，
// 与计划域季度滚动同口径）。候选对策按成本升序贪心覆盖，输出组合 + 残余 + 落地动作跳转。
// ---------------------------------------------------------------------------

function quarterOfLabel(dateIso: string): string {
  const y = Number(dateIso.slice(0, 4));
  const q = Math.floor((Number(dateIso.slice(5, 7)) - 1) / 3) + 1;
  return `${y}-Q${q}`;
}

function addQuartersLabel(label: string, n: number): string {
  const [yStr, qStr] = label.split("-Q") as [string, string];
  const idx = Number(yStr) * 4 + (Number(qStr) - 1) + n;
  return `${Math.floor(idx / 4)}-Q${(idx % 4) + 1}`;
}

/** 归一季度入参：接受 "2026Q2" / "2026-Q2" / "2026-q2"。 */
function normalizeQuarter(input: string): string {
  const m = /^(\d{4})-?[Qq]([1-4])$/.exec(input.trim());
  if (!m) throw validationError(`invalid quarter '${input}' (expected e.g. 2026-Q2)`);
  return `${m[1]}-Q${m[2]}`;
}

interface QuarterMeasure {
  key: string;
  name: string;
  costRank: number;
  releaseRatio: number;
  basis: "supply" | "demand" | "gap";
  action: string;
}

const DEFAULT_QUARTER_MEASURES: QuarterMeasure[] = [
  { key: "ramp_forward", name: "提前爬坡", costRank: 1, releaseRatio: 0.06, basis: "supply", action: "S07 产线认证排期 / 爬坡前置" },
  { key: "changeover_opt", name: "换型优化", costRank: 1, releaseRatio: 0.03, basis: "supply", action: "S11 换型排序优化" },
  { key: "maint_stagger", name: "错峰检修", costRank: 1, releaseRatio: 0.04, basis: "supply", action: "S13 检修窗口错峰" },
  { key: "outsource", name: "外协", costRank: 2, releaseRatio: 0.2, basis: "demand", action: "S14 外协决策（受 C08 封顶）" },
  { key: "defer", name: "顺延非战略单", costRank: 3, releaseRatio: Number.POSITIVE_INFINITY, basis: "gap", action: "顺延评审（罚，受 C29 冻结期约束）" },
];

export interface QuarterlyGapArgs {
  quarter: string;
}

/** 季度供给：周产能(万套) × 该基地最优认证系数 × 周曲线(检修周折减)，13 周聚合（与计划域季度滚动同源）。 */
function quarterlySupply(c: SolverContext, qi: number): number {
  const p = c.params;
  const wpq = p.planview.weeksPerQuarter;
  const rollup = computeRollup(c);
  const weekly = new Map(rollup.bases.map((b) => [b.baseId, b.weeklyWan]));
  const baseCert = new Map<string, number>();
  for (const m of c.certByModel.values()) {
    for (const [baseId, status] of m) {
      const f = p.certFactors[status] ?? 1;
      baseCert.set(baseId, Math.max(baseCert.get(baseId) ?? 0, f));
    }
  }
  let sup = 0;
  for (const [baseId, wk] of [...weekly.entries()].sort()) {
    const certFactor = baseCert.get(baseId) ?? 0;
    if (certFactor === 0) continue;
    const mp = c.maintPlans.find((m) => m.props.baseId === baseId);
    const mw = mp ? num(mp.props.week) : null;
    for (let w = qi * wpq + 1; w <= (qi + 1) * wpq; w++) sup += wk * certFactor * curveMult(p, w, mw);
  }
  return round(sup, 2);
}

export function quarterlyGap(c: SolverContext, args: QuarterlyGapArgs): Record<string, unknown> {
  const p = c.params;
  const quarter = normalizeQuarter(str(args.quarter));
  const startQ = quarterOfLabel(p.forecastStart);
  const qi = addQuartersOffset(startQ, quarter);
  if (qi < 0) throw validationError(`quarter ${quarter} precedes forecast start quarter ${startQ}`);

  // 需求：PlanTarget 季度目标 ×(1+滚动修正)；2027+ 按同季 ×(1+growthYoY)^n 外推；缺目标回落供给。
  const quarterTarget = new Map<string, number>();
  for (const t of c.planTargets) {
    if (str(t.props.level) === "quarter") quarterTarget.set(str(t.props.period), num(t.props.value));
  }
  const sup = quarterlySupply(c, qi);
  let target = quarterTarget.get(quarter);
  if (target === undefined) {
    const [yStr, qNo] = quarter.split("-Q") as [string, string];
    const base2026 = quarterTarget.get(`2026-Q${qNo}`);
    const yearsAhead = Number(yStr) - 2026;
    target = base2026 !== undefined && yearsAhead > 0 ? base2026 * Math.pow(1 + p.planview.growthYoY, yearsAhead) : sup;
  }
  const corr = p.planview.rollingCorrPct[qi] ?? 0;
  const dem = round(target * (1 + corr), 2);
  const gap = round(dem - sup, 2);

  const measures = c.params.quarterlyGap?.measures ?? DEFAULT_QUARTER_MEASURES;
  const basisValue = (basis: QuarterMeasure["basis"]) => (basis === "supply" ? sup : basis === "demand" ? dem : gap);

  const combination: Record<string, unknown>[] = [];
  let residual = Math.max(0, gap);
  if (gap > 0) {
    for (const mz of [...measures].sort((a, b) => a.costRank - b.costRank)) {
      if (residual <= 0) break;
      const cap = mz.releaseRatio === Number.POSITIVE_INFINITY ? residual : round(basisValue(mz.basis) * mz.releaseRatio, 4);
      const release = round(Math.min(residual, Math.max(0, cap)), 4);
      if (release <= 0) continue;
      residual = round(residual - release, 4);
      combination.push({ key: mz.key, name: mz.name, costRank: mz.costRank, release, action: mz.action });
    }
  }

  return {
    quarter,
    qi,
    demand: dem,
    supply: sup,
    gap,
    covered: round(Math.max(0, gap) - residual, 4),
    residual: round(residual, 4),
    combination,
    surplus: gap <= 0,
  };
}

/** 两季度标签之间的季度偏移（b − a）。 */
function addQuartersOffset(a: string, b: string): number {
  const idx = (label: string) => {
    const [yStr, qStr] = label.split("-Q") as [string, string];
    return Number(yStr) * 4 + (Number(qStr) - 1);
  };
  return idx(b) - idx(a);
}

// addQuartersLabel kept for symmetry with planviews quarter helpers (used by callers/tests).
export { addQuartersLabel, quarterOfLabel };
