import { describe, expect, it } from "vitest";
import { makeApp, seedBattery, invokeSolver, ADMIN } from "./helpers.js";
import { SOLVER_KEYS } from "../src/solvers/service.js";

/**
 * 20 场景端到端冒烟（DataCore 求解器运行时层）。
 * 对每个已注册求解器以"场景对齐"的代表性入参打真实 /solvers/invoke，断言 200 +
 * 无错误码 + 确定性（同输入同输出）。证明 13 个新求解器落地后 S01–S20 无 SOLVER_NOT_FOUND。
 * S18 sop_balance 为工作流/服务（非 /solvers），单独经 SOP 端点冒烟。
 */

// 各求解器的代表性入参（与 SCENARIO_CATALOG slotPresets 同义，映射到求解器真实入参）。
const SOLVER_ARGS: Record<string, Record<string, unknown>> = {
  capacity_rollup: {},
  capacity_forecast: { modelId: "4680-NCM", qty: 40, weeks: 6 }, // S01
  bottleneck_matrix: {},
  risk_timeline: { base: "常州", factor: "物料齐套", horizon: 30 }, // S03
  affected_orders: { baseId: "changzhou", day: 30, peak: 90 }, // S02
  plan_audit: { dem: 100, seg_pas: 50, seg_ess: 32, seg_com: 18, sup: 98, ltaCov: 60, kitGap: 100, gmTarget: 14, cashCushion: 55, capex: 8 }, // S04
  plan_generate: {}, // S05
  capex_scenario: { demand: [50, 48, 49, 51], s0: [45, 45, 45, 45], projects: [{ id: "P", name: "P", q0: 1, cap: 4, capex: [3, 5], m: 1800, salvageRate: 0.05, lifeQuarters: 40 }] }, // S17
  mitigation_select: { baseName: "常州", factor: "物料齐套" }, // S06
  outsourcing_split: { gap: 80000, weeks: 6 }, // S14
  maintenance_stagger: {}, // S13
  quarterly_gap: { quarter: "2026-Q4" }, // S19
  cert_schedule: { horizonWeeks: 12 }, // S07
  kit_readiness: { fromDay: 1, toDay: 14 }, // S08
  lta_gap: { material: "三元正极", month: "2026-07" }, // S09
  inventory_optimize: {}, // S10
  changeover_sequence: { lineId: "LINE-changzhou", week: 1 }, // S11
  quote_margin: { custName: "电网公司F", modelId: "4680-NCM", qty: 500 }, // S15
  credit_exposure: { custName: "商用车集团G" }, // S16
  carbon_footprint: { modelId: "4680-NCM", baseName: "成都" }, // S20
  yield_diagnosis: { processKey: "涂布", baseName: "常州" }, // S12
};

describe("20 场景端到端冒烟 — DataCore 求解器运行时（SL1 全绿基线）", () => {
  it("每个已注册求解器都有冒烟入参（覆盖完整 SOLVER_KEYS，无遗漏）", () => {
    for (const key of SOLVER_KEYS) expect(SOLVER_ARGS[key], `缺少 ${key} 的冒烟入参`).toBeDefined();
    expect(Object.keys(SOLVER_ARGS).sort()).toEqual([...SOLVER_KEYS].sort());
  });

  it("全部求解器真实调用 → 200 + 无错误 + 确定性（同输入同输出）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    for (const key of SOLVER_KEYS) {
      const args = SOLVER_ARGS[key]!;
      const r1 = await invokeSolver(t, key, args);
      expect(r1.statusCode, `${key}: ${r1.body}`).toBe(200);
      const d1 = (r1.json() as { data: Record<string, unknown> }).data;
      expect(d1, key).toBeTruthy();
      expect((d1 as { error?: unknown }).error, key).toBeUndefined();
      // 确定性：再次调用结果一致
      const r2 = await invokeSolver(t, key, args);
      expect((r2.json() as { data: unknown }).data, `${key} 非确定`).toEqual(d1);
    }
  });

  it("S18 sop_balance：SOP 月度平衡台经服务端点冒烟（创建版本 → 五步台）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const res = await t.app.inject({ method: "POST", url: "/a/v1/sop/versions", headers: ADMIN, payload: { month: "2026-07" } });
    expect([200, 201], res.body).toContain(res.statusCode);
    const v = res.json() as { id: string; step?: number };
    expect(v.id).toBeTruthy();
  });

  it("场景关键结论冒烟：碳超标(成都) / 信用冻结(G) / 外协有节省 / 季度缺口有对策", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const carbon = (await invokeSolver(t, "carbon_footprint", SOLVER_ARGS.carbon_footprint!).then((r) => r.json() as { data: { verdict: string } })).data;
    expect(carbon.verdict).toBe("超标");
    const credit = (await invokeSolver(t, "credit_exposure", SOLVER_ARGS.credit_exposure!).then((r) => r.json() as { data: { frozen: boolean } })).data;
    expect(credit.frozen).toBe(true);
    const outs = (await invokeSolver(t, "outsourcing_split", SOLVER_ARGS.outsourcing_split!).then((r) => r.json() as { data: { savings: number } })).data;
    expect(outs.savings).toBeGreaterThan(0);
    const qg = (await invokeSolver(t, "quarterly_gap", SOLVER_ARGS.quarterly_gap!).then((r) => r.json() as { data: { gap: number } })).data;
    expect(typeof qg.gap).toBe("number");
  });
});
