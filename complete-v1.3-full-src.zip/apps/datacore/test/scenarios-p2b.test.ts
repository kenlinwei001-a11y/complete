import { describe, expect, it } from "vitest";
import { makeApp, seedBattery, invokeSolver, type TestApp } from "./helpers.js";
import { BATTERY_SOLVER_PARAMS } from "../src/synthetic/battery.js";
import { round } from "../src/prng.js";

const P = BATTERY_SOLVER_PARAMS as {
  packCellCount: number;
  audit: { segMargins: { pas: number; ess: number; com: number } };
  affected: { problems: { essModels: string[]; comModels: string[] } };
  p2: {
    quote: { manufCostRate: number; logisticsCostRate: number; processFeeRate: number; targetMarginSpread: number };
    credit: { overdueLimitDays: number };
    carbon: { euThresholdKg: number };
    yield: { dropBaselinePct: number };
  };
};

async function solve(t: TestApp, key: string, args: Record<string, unknown>) {
  const res = await invokeSolver(t, key, args);
  expect(res.statusCode, `${key}: ${res.body}`).toBe(200);
  return (res.json() as { data: Record<string, unknown> }).data;
}

describe("20 场景 §2 · 第二阶段批次 B（客户/财务/碳/良率域）", () => {
  // --- S15 quote_margin -----------------------------------------------------
  it("V-S15: quote_margin — 毛利率=(价−成本)/价 恒等，BOM 参照重算，判定对比 C15 底线", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "quote_margin", { custName: "电网公司F", modelId: "4680-NCM", qty: 500 });
    const bd = out.breakdown as { bom: number; manuf: number; logistics: number; cost: number; price: number; discount: number; listPrice: number };

    // 毛利率恒等
    expect(out.margin).toBe(round((bd.price - bd.cost) / bd.price, 4));
    expect(bd.cost).toBe(round(bd.bom + bd.manuf + bd.logistics, 2));
    expect(bd.manuf).toBe(round(bd.bom * P.p2.quote.manufCostRate, 2));

    // BOM 参照重算（NCM：剔除铁锂正极）
    const mats = await t.repos.objects.listByType("demo", "Material");
    const ncm = mats.filter((m) => (m.props.category !== "正极") || String(m.props.materialId).includes("三元"));
    let bom = 0;
    for (const m of ncm) bom += round((m.props.bomPerCell as number) * P.packCellCount * (m.props.unitPrice as number) * (1 + P.p2.quote.processFeeRate), 2);
    expect(bd.bom).toBe(round(bom, 2));

    // 判定与底线一致（pas 段 18%）
    const floor = round(P.audit.segMargins.pas / 100, 4);
    expect(out.floor).toBe(floor);
    const expected = (out.margin as number) >= floor ? "过线" : (out.margin as number) >= floor - 0.01 ? "触线" : "低于底线";
    expect(out.verdict).toBe(expected);
  });

  // --- S16 credit_exposure --------------------------------------------------
  it("V-S16: credit_exposure — 商用车集团G 逾期→冻结(C32)；敞口=应收+在产；可用=额度−敞口", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const g = await solve(t, "credit_exposure", { custName: "商用车集团G", newOrderAmount: 1000000 });
    expect((g.overdueList as unknown[]).length).toBeGreaterThan(0); // 植入 38 天逾期
    expect(g.frozen).toBe(true);
    expect(String(g.verdict)).toContain("冻结");
    const bd = g.exposureBreakdown as { arOutstanding: number; inProduction: number };
    expect(g.exposure).toBe(round(bd.arOutstanding + bd.inProduction, 2));
    expect(g.available).toBe(round((g.creditLimit as number) - (g.exposure as number), 2));

    // 参照重算应收
    const invs = await t.repos.objects.listByType("demo", "ARInvoice");
    const ar = round(invs.filter((i) => i.props.custName === "商用车集团G" && i.props.status === "OPEN").reduce((a, i) => a + (i.props.amount as number), 0), 2);
    expect(bd.arOutstanding).toBe(ar);
  });

  // --- S20 carbon_footprint -------------------------------------------------
  it("V-S20: carbon_footprint — 成都超标/常州达标(电网因子×能耗差异)，总值=物料+能耗，参照重算", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const cd = await solve(t, "carbon_footprint", { modelId: "4680-NCM", baseName: "成都" });
    const cz = await solve(t, "carbon_footprint", { modelId: "4680-NCM", baseName: "常州" });

    expect(cd.total).toBe(round((cd.materialCarbon as number) + (cd.energyCarbon as number), 4));
    expect(cd.verdict).toBe("超标");
    expect(cz.verdict).toBe("达标");
    expect(cd.total as number).toBeGreaterThan(cz.total as number);
    expect(cd.threshold).toBe(P.p2.carbon.euThresholdKg);

    // 参照重算成都物料碳
    const mats = await t.repos.objects.listByType("demo", "Material");
    const ncm = mats.filter((m) => (m.props.category !== "正极") || String(m.props.materialId).includes("三元"));
    let matC = 0;
    for (const m of ncm) matC += round((m.props.bomPerCell as number) * (m.props.carbonFactor as number), 4);
    expect(cd.materialCarbon).toBe(round(matC, 4));
    // 最大改善杠杆是分解最大项
    expect((cd.maxLever as { kgCO2e: number }).kgCO2e).toBeGreaterThan(0);
  });

  // --- S12 yield_diagnosis --------------------------------------------------
  it("V-S12: yield_diagnosis — 涂布×常州检出突变(降幅≈2pct)+候选根因；卷绕×常州无突变", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const drop = await solve(t, "yield_diagnosis", { processKey: "涂布", baseName: "常州" });
    expect(drop.plantedDrop).toBe(true);
    expect(drop.changeDay).not.toBeNull();
    // 滑窗在阶跃边沿首次越过 2σ 阈即触发：降幅 > 检出阈、≤ 植入降幅，突变日落在植入日附近
    expect(drop.dropMagnitude as number).toBeGreaterThan(drop.detectionThreshold as number);
    expect(drop.dropMagnitude as number).toBeLessThanOrEqual(P.p2.yield.dropBaselinePct + 0.005);
    expect(drop.changeDay as number).toBeGreaterThanOrEqual(20);
    expect(drop.changeDay as number).toBeLessThanOrEqual(40);
    expect((drop.candidates as unknown[]).length).toBeGreaterThan(0);
    expect(drop.sustainTrigger).toBe((drop.dropMagnitude as number) >= P.p2.yield.dropBaselinePct); // C30

    const clean = await solve(t, "yield_diagnosis", { processKey: "卷绕", baseName: "常州" });
    expect(clean.plantedDrop).toBe(false);
    expect(clean.changeDay).toBeNull();

    // 确定性
    expect(await solve(t, "yield_diagnosis", { processKey: "涂布", baseName: "常州" })).toEqual(drop);
  });

  // --- 目录可见性 -----------------------------------------------------------
  it("批次 B 四求解器全部可解析（不再 SOLVER_NOT_FOUND）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const calls: Record<string, Record<string, unknown>> = {
      quote_margin: { custName: "电网公司F", modelId: "4680-NCM", qty: 500 },
      credit_exposure: { custName: "商用车集团G" },
      carbon_footprint: { modelId: "4680-NCM", baseName: "成都" },
      yield_diagnosis: { processKey: "涂布", baseName: "常州" },
    };
    for (const [key, args] of Object.entries(calls)) {
      const res = await invokeSolver(t, key, args);
      expect(res.statusCode, `${key}: ${res.body}`).toBe(200);
    }
  });
});
