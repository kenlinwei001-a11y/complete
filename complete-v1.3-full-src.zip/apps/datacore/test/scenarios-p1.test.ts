import { describe, expect, it } from "vitest";
import { makeApp, seedBattery, invokeSolver, type TestApp } from "./helpers.js";
import { BATTERY_SOLVER_PARAMS } from "../src/synthetic/battery.js";
import { round } from "../src/prng.js";

const P = BATTERY_SOLVER_PARAMS as {
  whatIf: { outsourceMax: number };
  risk: { mitigations: Record<string, { key: string; name: string; eff: number; tn: number; cost: string }[]> };
  bottleneck: { mock: Record<string, number>; primary: Record<string, string>; defaultPrimary: string };
  mitigationSelect: { costRank: Record<string, number>; urgencyBase: number; urgencyDen: number };
  outsourcing: { overtimeCostPer: number; outsourceCostPer: number; delayPenaltyPer: number; overtimeCapRatio: number };
  maintenanceStagger: { windowWeeks: number; topPeakWeeks: number };
};

async function solve(t: TestApp, key: string, args: Record<string, unknown>) {
  const res = await invokeSolver(t, key, args);
  expect(res.statusCode).toBe(200);
  return (res.json() as { data: Record<string, unknown> }).data;
}

describe("20 场景 §2 · 第一阶段求解器（参照实现双算）", () => {
  // --- S14 outsourcing_split ------------------------------------------------
  it("V-S14: outsourcing_split — 三渠道单位成本升序贪心，余量落延期罚（精确双算）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const gap = 80000;
    const out = await solve(t, "outsourcing_split", { gap, weeks: 6 });

    // independent recompute (PRD §2 公式)
    const c1 = P.outsourcing.overtimeCostPer;
    const c2 = P.outsourcing.outsourceCostPer;
    const c3 = P.outsourcing.delayPenaltyPer;
    const overtimeCap = gap * P.outsourcing.overtimeCapRatio; // 32000
    const outsourceCap = gap * P.whatIf.outsourceMax; // totalDemand defaults to gap → 16000
    const overtime = Math.min(gap, overtimeCap);
    const outsource = Math.min(gap - overtime, outsourceCap);
    const delay = gap - overtime - outsource;
    const totalCost = overtime * c1 + outsource * c2 + delay * c3;

    const alloc = out.allocations as { channel: string; qty: number; cost: number }[];
    expect(alloc.map((a) => a.channel)).toEqual(["overtime", "outsource", "delay"]);
    expect(alloc.find((a) => a.channel === "overtime")!.qty).toBe(overtime);
    expect(alloc.find((a) => a.channel === "outsource")!.qty).toBe(outsource);
    expect(alloc.find((a) => a.channel === "delay")!.qty).toBe(delay);
    expect(out.c08OutsourceCap).toBe(round(outsourceCap, 4));
    expect(out.totalCost).toBe(round(totalCost, 4));
    expect(out.allDelayCost).toBe(round(gap * c3, 4));
    expect(out.savings).toBe(round(gap * c3 - totalCost, 4));
    // C08 红线落在外协渠道注解上
    expect(String(alloc.find((a) => a.channel === "outsource") && (alloc.find((a) => a.channel === "outsource") as { note?: string }).note)).toContain("C08");

    // totalDemand 显式给定 → 外协上限放宽
    const out2 = await solve(t, "outsourcing_split", { gap, weeks: 6, totalDemand: 400000 });
    expect((out2.allocations as { channel: string; qty: number }[]).find((a) => a.channel === "outsource")!.qty).toBe(
      Math.min(gap - overtime, 400000 * P.whatIf.outsourceMax),
    );
  });

  // --- S06 mitigation_select ------------------------------------------------
  it("V-S06: mitigation_select — score=eff×urgency/(rank×tn) 降序 + 推荐首位 + 草稿 payload（双算）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const factor = "物料齐套";
    const out = await solve(t, "mitigation_select", { baseName: "常州", factor });

    // independent tightness (MOCK 口径，与 risk.ts 一致): 物料齐套 非常州主因 → secondary
    const bases = await t.repos.objects.listByType("demo", "Base");
    const util = bases.find((b) => b.props.baseId === "changzhou")!.props.util as number;
    const m = P.bottleneck.mock;
    const seed = ("常".charCodeAt(0) + factor.charCodeAt(0) * m.factorMult!) % m.mod!;
    const primary = P.bottleneck.primary["常州"] ?? P.bottleneck.defaultPrimary;
    const tightness =
      factor === primary
        ? Math.min(m.primaryCap!, m.primaryBase! + (seed % m.mod!))
        : Math.min(m.secondaryCap!, m.secondaryBase! + seed + (util > m.utilHigh! ? m.utilHighAdd! : m.utilLowAdd!));
    expect(out.tightness).toBe(tightness);

    const urgency = round(Math.max(0, (tightness - P.mitigationSelect.urgencyBase) / P.mitigationSelect.urgencyDen), 4);
    expect(out.urgency).toBe(urgency);

    const plans = P.risk.mitigations[factor]!;
    const expected = plans
      .map((pl) => {
        const rank = P.mitigationSelect.costRank[pl.cost] ?? 2;
        const tDays = Math.max(1, pl.tn);
        return { planKey: pl.key, score: round((pl.eff * urgency) / (rank * tDays), 6), costEff: round(pl.eff / (rank * tDays), 6) };
      })
      .sort((a, b) => b.score - a.score || b.costEff - a.costEff || (a.planKey < b.planKey ? -1 : 1));
    const options = out.options as { planKey: string; score: number }[];
    expect(options.map((o) => o.planKey)).toEqual(expected.map((e) => e.planKey));
    expect(out.recommended).toBe(expected[0]!.planKey);
    const draft = out.draftPayload as { planKey: string; factor: string; baseId: string };
    expect(draft.planKey).toBe(expected[0]!.planKey);
    expect(draft.factor).toBe(factor);
    expect(draft.baseId).toBe("changzhou");
  });

  // --- S13 maintenance_stagger ---------------------------------------------
  it("V-S13: maintenance_stagger — 冲突=检修周∈top3交付周，新周∈±4窗且负荷更低，确定性", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "maintenance_stagger", {});

    const peakWeeks = out.peakWeeks as number[];
    expect(peakWeeks.length).toBeLessThanOrEqual(P.maintenanceStagger.topPeakWeeks);
    const adjustments = out.adjustments as { origWeek: number; suggestedWeek: number; loadDrop: number; origLoad: number; newLoad: number }[];
    for (const a of adjustments) {
      // 原周是冲突高峰周
      expect(peakWeeks).toContain(a.origWeek);
      // 新周在 ±4 窗内、非高峰、负荷不高于原周
      expect(Math.abs(a.suggestedWeek - a.origWeek)).toBeLessThanOrEqual(P.maintenanceStagger.windowWeeks);
      expect(peakWeeks).not.toContain(a.suggestedWeek);
      expect(a.loadDrop).toBe(round(a.origLoad - a.newLoad, 2));
      expect(a.loadDrop).toBeGreaterThanOrEqual(0);
    }
    const unresolved = out.unresolved as { origWeek: number }[];
    for (const u of unresolved) expect(peakWeeks).toContain(u.origWeek);

    // 确定性：同种子同输出
    const out2 = await solve(t, "maintenance_stagger", {});
    expect(out2).toEqual(out);
  });

  // --- S19 quarterly_gap ----------------------------------------------------
  it("V-S19: quarterly_gap — gap=需求−供给（供给>0），对策成本升序贪心，covered+residual 自洽", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "quarterly_gap", { quarter: "2026Q4" });

    expect(out.quarter).toBe("2026-Q4");
    expect(out.supply).toBeGreaterThan(0);
    expect(out.gap).toBe(round((out.demand as number) - (out.supply as number), 2));

    const combo = out.combination as { costRank: number; release: number; action: string }[];
    // 成本秩非降序（升序贪心）
    for (let i = 1; i < combo.length; i++) expect(combo[i]!.costRank).toBeGreaterThanOrEqual(combo[i - 1]!.costRank);
    const releaseSum = round(combo.reduce((a, x) => a + x.release, 0), 4);
    expect(round(releaseSum + (out.residual as number), 4)).toBe(round(Math.max(0, out.gap as number), 4));
    expect(out.covered).toBe(releaseSum);
    // 每个对策都带落地场景跳转
    for (const m of combo) expect(m.action.length).toBeGreaterThan(0);

    // 季度归一 + 越界拒绝
    const cur = await solve(t, "quarterly_gap", { quarter: "2026-Q3" });
    expect(cur.qi).toBe(0);
    const bad = await invokeSolver(t, "quarterly_gap", { quarter: "2026-Q1" });
    expect(bad.statusCode).toBe(400); // validationError → 400
  });

  // --- 求解器目录可见性 ------------------------------------------------------
  it("四个新求解器进入目录端点（不再 SOLVER_NOT_FOUND）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    for (const key of ["mitigation_select", "outsourcing_split", "maintenance_stagger", "quarterly_gap"]) {
      const res = await invokeSolver(t, key, key === "outsourcing_split" ? { gap: 1000 } : key === "quarterly_gap" ? { quarter: "2026-Q4" } : key === "mitigation_select" ? { baseName: "常州", factor: "物料齐套" } : {});
      expect(res.statusCode, `${key} should resolve`).toBe(200);
    }
  });
});
