import { describe, expect, it } from "vitest";
import { makeApp, seedBattery, invokeSolver, type TestApp } from "./helpers.js";
import { BATTERY_SOLVER_PARAMS } from "../src/synthetic/battery.js";
import { round } from "../src/prng.js";

const P = BATTERY_SOLVER_PARAMS as {
  packCellCount: number;
  forecastStart: string;
  p2: {
    certSchedule: { engineerGroups: number };
    inventory: { runRateDays: number; overTargetMult: number; underTargetMult: number; dormantDays: number };
    lta: { poSplit: number };
  };
};

async function solve(t: TestApp, key: string, args: Record<string, unknown>) {
  const res = await invokeSolver(t, key, args);
  expect(res.statusCode, `${key}: ${res.body}`).toBe(200);
  return (res.json() as { data: Record<string, unknown> }).data;
}

const dayFrom = (dateIso: string) =>
  Math.round((Date.parse(`${dateIso.slice(0, 10)}T00:00:00Z`) - Date.parse(`${P.forecastStart}T00:00:00Z`)) / 86400000);

describe("20 场景 §2 · 第二阶段批次 A（物料/认证/换型域）", () => {
  // --- S07 cert_schedule ----------------------------------------------------
  it("V-S07: cert_schedule — 仅排认证中/待认证，priority 降序，C26 并行 ≤ 工程师组数，确定性", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "cert_schedule", { horizonWeeks: 12 });
    const schedule = out.schedule as { certId: string; status: string; priority: number; startWeek: number; finishWeek: number }[];
    expect(schedule.length).toBeGreaterThan(0);
    expect(schedule.every((s) => ["认证中", "待认证"].includes(s.status))).toBe(true);
    // priority 非升序
    for (let i = 1; i < schedule.length; i++) expect(schedule[i]!.priority).toBeLessThanOrEqual(schedule[i - 1]!.priority);
    // C26：任一周并行任务 ≤ engineerGroups
    const maxWeek = Math.max(...schedule.map((s) => s.finishWeek));
    for (let w = 1; w <= maxWeek; w++) {
      const running = schedule.filter((s) => s.startWeek <= w && w <= s.finishWeek).length;
      expect(running).toBeLessThanOrEqual(P.p2.certSchedule.engineerGroups);
    }
    expect(out.engineerGroups).toBe(P.p2.certSchedule.engineerGroups);
    expect(await solve(t, "cert_schedule", { horizonWeeks: 12 })).toEqual(out);
  });

  // --- S08 kit_readiness ----------------------------------------------------
  it("V-S08: kit_readiness — 逐单齐套率，缺料项仅 ratio<1 出现，单料齐套率参照重算", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "kit_readiness", { fromDay: 1, toDay: 60 });
    const orders = out.orders as { so: string; qty: number; kitRatio: number; shortages: { material: string }[]; startDay: number }[];
    expect(orders.length).toBeGreaterThan(0);
    for (const r of orders) {
      expect(r.kitRatio).toBeGreaterThanOrEqual(0);
      if (r.shortages.length > 0) expect(r.kitRatio).toBeLessThan(1);
      if (r.kitRatio >= 1) expect(r.shortages).toHaveLength(0);
    }

    // 参照重算：取首单，独立算各物料 avail/need 的最小比 = kitRatio
    const mats = await t.repos.objects.listByType("demo", "Material");
    const batches = await t.repos.objects.listByType("demo", "MaterialBatch");
    const ordObjs = await t.repos.objects.listByType("demo", "Order");
    const first = orders[0]!;
    const ord = ordObjs.find((o) => o.props.so === first.so)!;
    const oBases = new Set(ord.props.bases as string[]);
    const cells = (ord.props.qty as number) * P.packCellCount;
    let expMin = Infinity;
    for (const m of mats) {
      const need = (m.props.bomPerCell as number) * cells;
      if (need <= 0) continue;
      let stock = 0;
      const inT: { eta: number; kg: number }[] = [];
      for (const b of batches) {
        if (b.props.materialId !== m.props.materialId) continue;
        if (oBases.size > 0 && !oBases.has(b.props.baseId as string)) continue;
        const kg = (b.props.qtyTons as number) * 1000;
        if (b.props.status === "IN_TRANSIT") inT.push({ eta: b.props.etaDay as number, kg });
        else stock += kg;
      }
      const arrived = inT.filter((x) => x.eta <= first.startDay).reduce((a, x) => a + x.kg, 0);
      expMin = Math.min(expMin, round((stock + arrived) / need, 4));
    }
    expect(first.kitRatio).toBe(Number.isFinite(expMin) ? expMin : 1);
    expect(out.shortageCount).toBe(orders.filter((r) => r.kitRatio < 1).length);
  });

  // --- S09 lta_gap ----------------------------------------------------------
  it("V-S09: lta_gap — 净需求/覆盖率/缺口参照重算；非法月份→400", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const material = "三元正极";
    const month = "2026-07";
    const out = await solve(t, "lta_gap", { material, month });

    const mats = await t.repos.objects.listByType("demo", "Material");
    const batches = await t.repos.objects.listByType("demo", "MaterialBatch");
    const ordObjs = await t.repos.objects.listByType("demo", "Order");
    const m = mats.find((x) => x.props.materialId === material)!;
    const bom = m.props.bomPerCell as number;
    const monthCells = ordObjs.filter((o) => String(o.props.due).slice(0, 7) === month).reduce((a, o) => a + (o.props.qty as number) * P.packCellCount, 0);
    const monthDemandKg = round(monthCells * bom, 2);
    let stock = 0, inTransit = 0;
    for (const b of batches) {
      if (b.props.materialId !== material) continue;
      const kg = (b.props.qtyTons as number) * 1000;
      if (b.props.status === "IN_TRANSIT") inTransit += kg; else stock += kg;
    }
    const net = round(Math.max(0, monthDemandKg - stock - inTransit), 2);
    const monthlyQuota = round((monthDemandKg * 12 * (m.props.ltaLockRatio as number)) / 12, 2);
    const spotGap = round(Math.max(0, net - monthlyQuota), 2);

    expect(out.monthDemandTons).toBe(round(monthDemandKg / 1000, 3));
    expect(out.netDemandTons).toBe(round(net / 1000, 3));
    expect(out.spotGapTons).toBe(round(spotGap / 1000, 3));
    if (spotGap > 0) expect((out.suggestedPOs as unknown[]).length).toBe(P.p2.lta.poSplit);

    const bad = await invokeSolver(t, "lta_gap", { material, month: "2026/07" });
    expect(bad.statusCode).toBe(400);
  });

  // --- S10 inventory_optimize ----------------------------------------------
  it("V-S10: inventory_optimize — 呆滞≥90日批次被检出（植入6批），可释放资金=Σ超储×单价，确定性", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const out = await solve(t, "inventory_optimize", {});
    const dormant = out.dormant as { batchId: string; ageDays: number; lastConsumedDays: number }[];
    expect(dormant.length).toBeGreaterThanOrEqual(6); // §7 植入 6 批呆滞
    for (const d of dormant) expect(Math.max(d.ageDays, d.lastConsumedDays)).toBeGreaterThanOrEqual(P.p2.inventory.dormantDays);
    // 可释放资金 = Σ 超储清单 releasableYuan
    const over = out.overStock as { releasableYuan: number }[];
    expect(out.releasableYuan).toBe(round(over.reduce((a, x) => a + x.releasableYuan, 0), 2));
    expect(out.releasableYuan as number).toBeGreaterThanOrEqual(0);
    expect(await solve(t, "inventory_optimize", {})).toEqual(out);
  });

  // --- S11 changeover_sequence ---------------------------------------------
  it("V-S11: changeover_sequence — 序列是订单集的排列，贪心总时长≤交期序，确定性", async () => {
    const t = await makeApp();
    await seedBattery(t);
    // 找一个有 ≥2 单的 (基地, 周)
    const ordObjs = await t.repos.objects.listByType("demo", "Order");
    const byBaseWeek = new Map<string, number>();
    for (const o of ordObjs) {
      const d = dayFrom(String(o.props.due));
      const w = Math.ceil(d / 7); // solver window: (w-1)*7 < d <= w*7
      if (w >= 1) for (const b of o.props.bases as string[]) byBaseWeek.set(`${b}|${w}`, (byBaseWeek.get(`${b}|${w}`) ?? 0) + 1);
    }
    const hit = [...byBaseWeek.entries()].find(([, n]) => n >= 2);
    const lines = await t.repos.objects.listByType("demo", "Line");
    if (hit) {
      const [baseId, wk] = hit[0].split("|");
      const line = lines.find((l) => l.props.baseId === baseId)!;
      const out = await solve(t, "changeover_sequence", { lineId: line.props.lineId, week: Number(wk) });
      const seq = out.sequence as { so: string }[];
      expect(seq.length).toBeGreaterThanOrEqual(2);
      // 排列：so 集合一致、无重复
      expect(new Set(seq.map((s) => s.so)).size).toBe(seq.length);
      // 贪心总时长 ≤ 交期序时长（最近邻不劣于任意固定序，至少不超过基线显著）
      expect(out.totalChangeoverMin as number).toBeLessThanOrEqual(out.dueSeqChangeoverMin as number);
      expect(out.savedMin).toBe(round((out.dueSeqChangeoverMin as number) - (out.totalChangeoverMin as number), 2));
      expect(await solve(t, "changeover_sequence", { lineId: line.props.lineId, week: Number(wk) })).toEqual(out);
    }
    // 空周 → 空序列
    const empty = await solve(t, "changeover_sequence", { lineId: (lines[0]!.props.lineId as string), week: 999 });
    expect(empty.sequence).toHaveLength(0);
    expect(empty.totalChangeoverMin).toBe(0);
  });

  // --- 目录可见性 -----------------------------------------------------------
  it("批次 A 五求解器全部可解析（不再 SOLVER_NOT_FOUND）", async () => {
    const t = await makeApp();
    await seedBattery(t);
    const lines = await t.repos.objects.listByType("demo", "Line");
    const calls: Record<string, Record<string, unknown>> = {
      cert_schedule: { horizonWeeks: 12 },
      kit_readiness: { fromDay: 1, toDay: 14 },
      lta_gap: { material: "碳酸锂", month: "2026-07" },
      inventory_optimize: {},
      changeover_sequence: { lineId: lines[0]!.props.lineId, week: 1 },
    };
    for (const [key, args] of Object.entries(calls)) {
      const res = await invokeSolver(t, key, args);
      expect(res.statusCode, `${key}: ${res.body}`).toBe(200);
    }
  });
});
