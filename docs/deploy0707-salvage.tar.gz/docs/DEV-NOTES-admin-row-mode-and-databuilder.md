# DEV-NOTES · Admin 行模式改造 + DataBuilder 管线摊平

> 本文档记录 2026-07-08 批次改动的**实现模式、关键文件、踩坑记录**，供后续 agent 同步，避免重复踩坑。

---

## 1. Admin 页面统一筛选/排序/空态/计数（6 页）

### 背景
此前 Agents、Skills、Workflows、Mcp、Catalog、Knowledge 6 个 Admin 页只有列表，**无筛选、无排序、无空态引导、无统计计数**。用户问"每个页面都可以筛选字段吗"时发现大面积遗漏。

### 统一实现模式（以 SkillsPage 为标杆）

```tsx
// 1. 四件套状态
const [searchText, setSearchText] = useState("");
const [statusFilter, setStatusFilter] = useState("");
const [sortBy, setSortBy] = useState<"createdAt" | "name" | "status">("createdAt");
const [sortDesc, setSortDesc] = useState(true);

// 2. 派生过滤+排序列表（前端内存计算，不走 API）
const filtered = (items ?? [])
  .filter((s) => {
    if (searchText && !s.name.toLowerCase().includes(searchText.toLowerCase())) return false;
    if (statusFilter && s.status !== statusFilter) return false;
    return true;
  })
  .sort((a, b) => {
    let cmp = 0;
    if (sortBy === "createdAt") cmp = (a.createdAt ?? "").localeCompare(b.createdAt ?? "");
    else if (sortBy === "name") cmp = a.name.localeCompare(b.name);
    else if (sortBy === "status") cmp = a.status.localeCompare(b.status);
    return sortDesc ? -cmp : cmp;
  });

// 3. 工具栏渲染（筛选 + 排序 + 统计）
<div className="panel" style={{ marginBottom: 14, padding: "10px 12px" }}>
  <div style={{ display: "flex", flexWrap: "wrap", gap: "8px 12px", alignItems: "center" }}>
    <span className="section-title" style={{ margin: 0, fontSize: 12 }}>筛选</span>
    {/* 名称搜索 */}
    <input data-testid="skill-filter-name" value={searchText} onChange={...} placeholder="搜索名称" style={{ width: 120, fontSize: 12 }} />
    {/* 状态下拉 */}
    <select data-testid="skill-filter-status" value={statusFilter} onChange={...} style={{ fontSize: 12 }}>
      <option value="">全部</option>
      <option value="DRAFT">DRAFT</option>
      <option value="PUBLISHED">PUBLISHED</option>
      <option value="RETIRED">RETIRED</option>
    </select>
    {/* 排序 */}
    <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
      <span className="muted" style={{ fontSize: 12 }}>排序</span>
      <select value={sortBy} onChange={...} style={{ fontSize: 12 }}>
        <option value="createdAt">创建时间</option>
        <option value="name">名称</option>
        <option value="status">状态</option>
      </select>
      <button className="btn sm" onClick={() => setSortDesc((v) => !v)} title={sortDesc ? "降序" : "升序"}>
        {sortDesc ? "↓" : "↑"}
      </button>
    </div>
  </div>
  <div style={{ fontSize: 11.5, color: "var(--muted)", marginTop: 6 }}>
    共 {(items ?? []).length} 个技能 · 命中 {filtered.length} 个
  </div>
</div>

// 4. 空态引导（两种：全局无数据 + 筛选无命中）
{(items ?? []).length === 0 && (
  <EmptyState message="暂无技能">
    <button className="btn primary sm" onClick={() => createMut.mutate()} data-testid="cta-skill">＋新建技能</button>
  </EmptyState>
)}
{filtered.length === 0 && (items ?? []).length > 0 && (
  <div className="empty-state" style={{ padding: "24px 12px" }}>
    无匹配技能——请调整筛选条件
  </div>
)}
```

### 各页状态字段对照

| 页面 | 状态选项 | testid 前缀 | 备注 |
|---|---|---|---|
| AgentsPage | DRAFT / PUBLISHED / RETIRED | `agent-*` | 按 key 去重取最新版本 |
| SkillsPage | DRAFT / PUBLISHED / RETIRED | `skill-*` | 直接数组 |
| WorkflowsPage | DRAFT / PUBLISHED / RETIRED | `workflow-*` | 直接数组 |
| McpPage | ACTIVE / DISABLED / ERROR | `mcp-*` | 直接数组 |
| CatalogPage | DRAFT / PUBLISHED / RETIRED | `catalog-*` | 状态仍走 API queryKey，名称前端过滤 |
| KnowledgePage | ACTIVE / DISABLED / ERROR | `kb-*` | connections 列表 |

### 踩坑记录
1. **EmptyState 组件未 import**：SkillsPage.tsx、WorkflowsPage.tsx 早期版本用了 `<EmptyState>` 但忘 import，build 报错 `TS2304: Cannot find name 'EmptyState'`。**所有新增空态的页面必须检查 import**。
2. **locale 键不存在**：`zh.admin.empty.skills` / `zh.admin.empty.workflows` 不存在（`zh.ts` 只定义了 `connections`、`ontology`、`intents`、`agents`）。**直接用硬编码字符串**，别假设 locale 键存在。
3. **CatalogPage 状态筛选仍走 API**：Catalog 的状态下拉改变的是 API queryKey（`["b", "catalog", { status }]`），不是前端内存过滤。这是历史设计，保留不动；名称搜索才是前端过滤。

---

## 2. DataBuilderPage · OperationalPipelineBoard 摊平 StoryBuildRun

### 需求
把每个连接器的**同步状态、关联数据集、关联隔离区、关联 StoryBuildRun** 都摊平成一行，不要丢失字段。

### 改动点

#### 2.1 扩展 PipelineSourceRow 接口

```tsx
interface PipelineSourceRow {
  // ... 原有字段 ...
  quarantineCount: number;
  // g8：每个连接器关联的 StoryBuildRun 摊平字段
  storyRunCount: number;
  lastStoryRunAt?: string;
  lastStoryRunStatus?: string;
  lastStoryScript?: string;
}
```

#### 2.2 新增 story-runs 查询

```tsx
const storyQ = useQuery<StoryBuildRun[]>({ queryKey: ["a", "story-runs"], queryFn: fetchStoryRuns });
const storyRuns = storyQ.data ?? [];
```

#### 2.3 行计算时关联 runs

```tsx
const rows: PipelineSourceRow[] = conns.map((c) => {
  // ... 原有 ds / qrows 计算 ...
  const runs = storyRuns.filter((r) => r.producedConnections.includes(c.id));
  const sortedRuns = runs.sort((a, b) => (b.createdAt ?? "").localeCompare(a.createdAt ?? ""));
  const lastRun = sortedRuns[0];
  return {
    // ... 原有字段 ...
    quarantineCount: qrows.length,
    storyRunCount: runs.length,
    lastStoryRunAt: lastRun?.createdAt,
    lastStoryRunStatus: lastRun?.status,
    lastStoryScript: lastRun?.script?.slice(0, 60),
  };
});
```

> **关联键**：`StoryBuildRun.producedConnections: string[]` 存连接器 id，前端用 `includes(c.id)` 匹配。

#### 2.4 表格新增 4 列

| 列 | 字段 | 样式 |
|---|---|---|
| 建域次数 | `storyRunCount` | 纯数字 |
| 最近建域 | `lastStoryRunAt` | `mono` 字体，同 last sync 截断格式 `YYYY-MM-DD HH:mm` |
| 建域状态 | `lastStoryRunStatus` | SUCCEEDED=绿 / FAILED=红 / 其他=琥珀 |
| 最近脚本 | `lastStoryScript` | 截断 60 字，`ellipsis` + `title` 悬停全文本 |

表头新增：`<th>建域次数</th><th>最近建域</th><th>建域状态</th><th>最近脚本</th>`

数据 cell 插入在**隔离列之后、同步按钮之前**。

### 踩坑记录
1. **worktree 文件被覆盖**：本文件在 worktree 中因其他 agent 同步组件目录时被意外回滚。**修改前务必先 grep 确认目标代码仍在**。
2. **story-runs API 已存在**：`fetchStoryRuns` 和 `StoryBuildRun` 类型在 `endpoints.ts` / `contracts` 中已有定义，无需新建。**mock handlers** 中 `db.storyRuns` 内存数据默认 `producedConnections: []`，如需验证关联效果，需在 mock 中给 run 填入对应 connId。

---

## 3. 测试回归

### 必跑测试
```bash
# g4 自助创建入口（Skills/Workflows）
pnpm --filter frontend-shell test --run test/g4.self-service-create.test.tsx

# 全量前端测试（worktree 环境可能因文件缺失大量失败，以 main repo 为准）
pnpm -r build && pnpm -r test
```

### 已知 worktree 问题
- worktree 的 `apps/frontend-shell/src/api/endpoints.ts`、`components/*` 可能滞后于 main repo。若出现 `Module has no exported member` 或 `Cannot find module`，**优先从 main repo `cp` 同步**。
- 全量测试的 `Unhandled Rejection: AbortSignal` 是 vitest/msw 环境兼容问题，非业务回归。

---

## 4. 文件清单（本批次改动）

| 文件 | 改动 |
|---|---|
| `apps/frontend-shell/src/pages/admin/AgentsPage.tsx` | +筛选栏 +排序 +空态 +计数 |
| `apps/frontend-shell/src/pages/admin/SkillsPage.tsx` | +筛选栏 +排序 +空态 +计数 |
| `apps/frontend-shell/src/pages/admin/WorkflowsPage.tsx` | +筛选栏 +排序 +空态 +计数 |
| `apps/frontend-shell/src/pages/admin/McpPage.tsx` | +筛选栏 +排序 +空态 +计数 |
| `apps/frontend-shell/src/pages/admin/CatalogPage.tsx` | +筛选栏 +排序 +空态 +计数（状态仍走 API） |
| `apps/frontend-shell/src/pages/admin/KnowledgePage.tsx` | +筛选栏 +排序 +空态 +计数 |
| `apps/frontend-shell/src/pages/admin/DataBuilderPage.tsx` | OperationalPipelineBoard +StoryBuildRun 4 列摊平 |

---

## 5. 后续 agent 同步检查单

- [ ] 如果新增 Admin 列表页，**复制 SkillsPage 的四件套模式**（search + status + sort + count），别从零写。
- [ ] 使用 `<EmptyState>` 时**确认已 import**，且 locale 键不存在时**降级硬编码字符串**。
- [ ] 修改 DataBuilderPage 前**先 grep 确认 PipelineSourceRow / OperationalPipelineBoard 代码存在**，防止被其他同步覆盖。
- [ ] mock 模式验证 StoryBuildRun 关联时，**检查 `db.storyRuns[*].producedConnections` 是否包含目标 connId**。
