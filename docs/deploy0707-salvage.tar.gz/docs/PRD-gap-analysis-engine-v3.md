# PRD：统一 GapAnalysis 引擎与补齐闭环治理 · v3（务实进化版）

> 状态：草案待审  
> 作者：Claude  
> 日期：2026-07-08  
> 版本：v3  
> 前置阅读：`docs/PRD-gap-analysis-engine.md`（v1 原始需求）、`docs/PRD-gap-analysis-engine-v2.md`（v2 理想设计）

---

## 0. v3 与 v2 的关系：从"推倒重来"到"务实进化"

v2 是一份**理想设计**——它假设我们可以从零构建一个 7 层图验证器、图重写引擎、覆盖率评分系统和自动修复循环。  
v3 是一份**务实设计**——它在完整代码审计的基础上，承认现有系统已经存在有效机制，选择**扩展而非替换**。

### v2 被否决的假设（审计发现）

| v2 假设 | 审计发现 | 结论 |
|---|---|---|
| `classifyGap()` 可以扩展为多发现诊断 | `classifyGap()` 永远只返回 **1 个 finding**（按 QOS 终态一次只报一个阻塞点） | 不修改 `classifyGap`，另建 `preAnalyzeQuery()` |
| DataBuilder 的 gap 分析需要被替换 | `apps/datacore/src/databuilder/provisioners.ts` 已有 `MODULE_PROVISIONERS` + `analyzeGap()`，工作良好 | 扩展 `analyzeGap`，不替换 |
| 需要常驻 Redis 缓存 + domain event 失效的 `SystemCapabilityRegistry` | 后端没有 pub/sub 事件总线；`event-subscriptions.ts` 仅是前端 SSE 路由表 | Registry 改为"按需聚合查询"，TTL 用 HTTP 缓存头 |
| 7 层图验证器 + Coverage Score + Auto Repair Loop | 现有 `ClosureReport`（5 维度）+ `selfcheck.ts` 已实现等效验证 | 复用现有验证，不新建图引擎 |
| PRE_ANALYSIS 可以阻塞在 `submitQuery()` 之前 | `submitQuery()` 立即返回 SSE streamUrl，阻塞会杀死实时体验 | PRE_ANALYSIS 改为**异步后台任务** |

### v3 的核心策略

1. **统一契约**：扩展 `packages/contracts` 中的 `GapAnalysis`，使其同时兼容 DataBuilder（script 目标）和 Growth Loop（query 目标）。
2. **一个引擎，两种入口**：`analyzeGap()` 仍是唯一 diff 引擎，但新增支持从 query 推导需求树。
3. **异步预分析**：`preAnalyzeQuery()` 在后台运行，不阻塞 QOS SSE 流。
4. **依赖排序复用现有 side 顺序**：`MODULE_PROVISIONERS` 已有的 `side` 字段（content → structure → code → cross_system）天然构成拓扑序。
5. **诚实的时间线**：不做需要 3 个月基础设施建设的假设，6 周内可交付。

---

## 1. 现状（As-Is）——审计后的精确描述

### 1.1 已存在的有效机制（不要重新发明）

**① DataBuilder 的 gap 分析（`apps/datacore/src/databuilder/provisioners.ts`）**

```typescript
export const MODULE_PROVISIONERS: ModuleProvisioner[] = [
  { kind: "dataset", side: "content", autoCreatable: true, planned: (p) => ..., existing: async (...) => ... },
  { kind: "ontology_type", side: "structure", autoCreatable: true, ... },
  { kind: "solver", side: "code", autoCreatable: false, ... },
  { kind: "intent", side: "cross_system", autoCreatable: true, ... },
  // ... 13 类模块
];

export async function analyzeGap(deps, ctx, plan, scaffoldReceipt?): Promise<GapAnalysis> { ... }
```

- 13 类模块全覆盖，新增模块有测试门禁（`provisioners.test`）。
- 输出 `GapAnalysis = { entries[], totals, generatedAt }`，每 entry 有 `needed/existing/toCreate/missing`。
- **这个机制工作良好，v3 直接复用。**

**② Growth Loop 的探针（`apps/agentcore/src/growth/probe.ts`）**

```typescript
export function classifyGap(task: QueryTask): GapReport {
  // 永远只返回 1 个 finding
  // ① Path A VERIFIED → ANSWERABLE / EMPTY_DATA
  // ② FAILED → 按 error code 映射
  // ③ Path B → NO_INTENT / NO_CAPABILITY
  // ④ Other → OTHER
}
```

- 设计意图就是"撞到哪堵墙就报哪堵墙"。
- `GapReport.findings` 永远是单元素数组（或空）。
- **这个机制是 reactive loop 的基石，不动它。**

**③ DataBuilder 的闭包验证（`apps/datacore/src/databuilder/service.ts` + `selfcheck.ts`）**

- `ClosureReport` 已有 5 维度验证：`gatePassed, objectsBound, dataOrphans, forwardMissing, solverCount`。
- `selfcheck.ts` 把 ClosureReport + ScaffoldReceipt 映射到 `GapReport` 的 11 个 `GapCode`。
- **这是 v2 想要的"验证层"的现有实现。**

**④ 事件订阅表（`apps/agentcore/src/event-subscriptions.ts`）**

```typescript
export const EVENT_SUBSCRIPTIONS = [
  { event: "ontology.published", invalidates: ["object-types", ...] },
  { event: "growth.gap_detected", invalidates: ["growth-ledger"] },
  // ...
];
```

- **仅前端缓存失效路由表**，不是后端消息总线。没有 pub/sub、没有 Redis 事件流。
- v2 假设的"domain event 失效缓存"在这套代码里不存在。

### 1.2 真实痛点（ unchanged from v1 ）

1. **用户不知道系统缺什么全景**：工单中心只显示当前工单，没有"本查询涉及 4 项缺口，这是第 2 项"的上下文。
2. **补齐顺序是发现顺序而非依赖顺序**：Growth Loop 的 K 轮循环每轮只补 `findings[0]`，但发现顺序 ≠ 依赖顺序。
3. **两套 Gap 数据结构不互通**：DataBuilder 的 `GapAnalysis` 和 Growth Loop 的 `GapReport` 类型不同、存储不同、从不交叉引用。
4. **补齐后验证标准不一致**：GapCard 看 `CONVERGED`，DataBuilder 看 `ClosureReport`，其他入口无验证。

---

## 2. 设计目标（Design Goals）

| 目标 | 描述 | 优先级 | v3 策略 |
|---|---|---|---|
| G1：统一缺口诊断契约 | DataBuilder 和 Growth Loop 输出同一种 `GapAnalysis` | P0 | 扩展 `GapAnalysis` 类型，两边都输出它 |
| G2：补齐优先级排序 | 基于模块依赖关系自动排序 | P0 | 复用 `MODULE_PROVISIONERS[].side` 做拓扑序 |
| G3：异步全景预分析 | 用户提问后，后台给出"本查询涉及 N 项缺口" | P1 | 新增 `preAnalyzeQuery()`，后台异步执行 |
| G4：补齐后统一验证 | 所有补齐完成后用同一套标准验证 | P1 | 复用 `ClosureReport` / `verifyBuild()` |
| G5：补齐入口归集 | 所有补齐触发统一收口到工单系统 | P2 | 扩展 `TicketCenterPage` 展示全景 |

---

## 3. 统一契约设计

### 3.1 扩展 `GapAnalysis`（`packages/contracts/src/databuilder.ts`）

现有 `GapAnalysis` 只服务于 DataBuilder（script 目标）。v3 扩展它以兼容 query 目标：

```typescript
// 新增：目标描述（统一两种入口）
export const GapTargetSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("script"), script: z.string(), seed: z.number().optional() }),
  z.object({ kind: z.literal("query"), query: z.string(), context: z.object({ base: z.string().optional(), segment: z.string().optional() }).optional() }),
  z.object({ kind: z.literal("scenario"), scenarioId: z.string(), triggerQuestion: z.string().optional() }),
]);
export type GapTarget = z.infer<typeof GapTargetSchema>;

// 新增：病因（不只是 GapCode 症状）
export const GapRootCauseSchema = z.object({
  symptom: GapCodeSchema,           // 症状：EMPTY_DATA / NO_RULE / ...
  cause: z.enum(["NOT_EXISTS", "INCOMPLETE", "VERSION_MISMATCH", "DEPENDENCY_MISSING", "MANUAL_REQUIRED"]),
  detail: z.string(),
});

// 新增：补齐策略
export const GapRemediationSchema = z.object({
  strategy: z.enum(["AUTO", "AUTO_WITH_APPROVAL", "MANUAL", "DEVELOP"]),
  action: z.string(),
  estimatedEffort: z.enum(["SECONDS", "MINUTES", "HOURS", "DAYS"]),
  canBeParallel: z.boolean(),
  prerequisites: z.array(z.string()), // 前置 GapEntry key refs
});

// 新增：Severity 分级（RG Engine Ch9.13）
export const GapSeveritySchema = z.enum(["INFO", "WARNING", "ERROR", "BLOCKER"]);
export type GapSeverity = z.infer<typeof GapSeveritySchema>;

// 新增：可解释性（RG Engine Ch11/Ch12.11）
export const GapExplanationSchema = z.object({
  why: z.string(),           // 为什么缺？例如"订单影响分析需要 order_impact 求解器"
  evidence: z.string(),      // 依据？例如"意图分析器识别到 IMPACT_ANALYSIS 意图"
  alternative: z.string().optional(), // 替代方案？例如"可用 generic-inference 临时兜底，但准确率降低"
});

// 扩展 GapItem（单个缺口项）
export const GapItemSchema = z.object({
  key: z.string(),
  status: GapStatusSchema,
  // v3 新增（可选，向后兼容）
  severity: GapSeveritySchema.optional(),      // 缺口严重程度
  explanation: GapExplanationSchema.optional(), // 为什么缺/依据/替代方案
  rootCause: GapRootCauseSchema.optional(),
  remediation: GapRemediationSchema.optional(),
  downstream: z.array(z.string()).optional(), // 补齐后会影响哪些下游 key
});

// 扩展 GapAnalysisEntry（单模块汇总）
export const GapAnalysisEntrySchema = z.object({
  kind: ModuleKindSchema,
  side: z.enum(["content", "structure", "code", "cross_system"]),
  needed: z.number().int(),
  existing: z.number().int(),
  toCreate: z.number().int(),
  missing: z.number().int(),
  items: z.array(GapItemSchema),
});

// 新增：执行步骤（依赖排序后）
export const ExecutionStepSchema = z.object({
  step: z.number().int(),
  entries: z.array(z.string()), // 本轮可并行执行的 GapItem.key
  rationale: z.string(),
});

// 扩展 GapAnalysis（统一报告）
export const GapAnalysisSchema = z.object({
  target: GapTargetSchema,          // v3 新增：本报告对应的目标
  entries: z.array(GapAnalysisEntrySchema),
  totals: z.object({
    needed: z.number(),
    existing: z.number(),
    toCreate: z.number(),
    missing: z.number(),
    reusable: z.number().optional(),
    coverageScore: z.number().min(0).max(1).optional(), // v3 新增：覆盖率 0~1
  }),
  executionPlan: z.array(ExecutionStepSchema).optional(), // v3 新增
  generatedAt: z.string(),
});
```

**向后兼容性**：
- DataBuilder 现有代码调用 `analyzeGap()` 时不需要传 `target`；`GapAnalysis.target` 可以在上层填充。
- `severity` / `explanation` / `rootCause` / `remediation` / `executionPlan` / `coverageScore` 都是 `optional()`，不影响现有序列化。

### 3.2 新增 `PreAnalysisReport`（`packages/contracts/src/growth.ts`）

```typescript
/** 异步预分析报告：后台跑完 preAnalyzeQuery 后给用户看的"全景"。 */
export const PreAnalysisReportSchema = z.object({
  query: z.string(),
  taskId: z.string(),                // 关联的 QOS task（可能还在跑）
  gapAnalysisId: z.string(),         // 关联的统一 GapAnalysis ID
  status: z.enum(["RUNNING", "DONE", "FAILED"]),
  summary: z.object({
    totalGaps: z.number(),
    autoFixable: z.number(),         // strategy=AUTO | AUTO_WITH_APPROVAL
    manualRequired: z.number(),      // strategy=MANUAL
    developRequired: z.number(),     // strategy=DEVELOP
    estimatedSteps: z.number(),      // ExecutionPlan 步数
  }),
  // 用户确认后开始系统性补齐；否的话继续 reactive loop
  userConfirmedAt: z.string().optional(),
});
export type PreAnalysisReport = z.infer<typeof PreAnalysisReportSchema>;
```

---

## 4. GapAnalysis 引擎（务实版）

### 4.1 核心洞察：`MODULE_PROVISIONERS` 就是 Registry

v2 想要一个 `SystemCapabilityRegistry` 常驻缓存。v3 发现：**`MODULE_PROVISIONERS` 本身就是 Registry 的查询定义**。  
每个 provisioner 的 `existing()` 函数就是 Registry 的 getter。不需要新建服务，只需要统一调用它们。

**全局最优：DataCore 提供统一 Registry Snapshot 端点**

复用 `datacoreClient` 调分散端点是走捷径（局部最优）。全局最优是 DataCore 暴露一个聚合端点，AgentCore 和所有未来消费者一次性拉取全部 13 类模块的 key 集合。

```typescript
// apps/datacore/src/databuilder/provisioners.ts —— 新增 HTTP 端点

/** GET /a/v1/registry/snapshot
 * 返回当前租户全部模块的现有 key 集合（轻量封装，1 天工作量）。
 * 内部实现：遍历 MODULE_PROVISIONERS，并行调用各 existing() 函数。
 */
export async function getRegistrySnapshot(deps: ProvisionerDeps, ctx: AuthCtx): Promise<Record<ModuleKind, string[]>> {
  const result: Partial<Record<ModuleKind, string[]>> = {};
  await Promise.all(
    MODULE_PROVISIONERS.map(async (prov) => {
      const keys = prov.existing ? [...await prov.existing(deps, ctx)] : [];
      result[prov.kind] = keys;
    })
  );
  return result as Record<ModuleKind, string[]>;
}
```

```typescript
// apps/agentcore/src/growth/capability-registry.ts

export interface CapabilityRegistry {
  snapshot(tenantId: string): Promise<Record<ModuleKind, Set<string>>>;
}

/** 全局最优实现：优先调用 DataCore 统一 snapshot，fallback 到分散端点 */
export function createHttpCapabilityRegistry(datacore: DatacoreClient, agentRepos: AgentRepos): CapabilityRegistry {
  return {
    async snapshot(tenantId) {
      // ① 优先调用 DataCore 统一 snapshot（全局基础设施）
      try {
        const snap = await datacore.get("/a/v1/registry/snapshot", tenantId);
        return Object.fromEntries(
          MODULE_KINDS.map((k) => [k, new Set(snap[k] ?? [])])
        ) as Record<ModuleKind, Set<string>>;
      } catch {
        // ② fallback：分散调用（兼容旧路径，不阻塞）
        const map: Partial<Record<ModuleKind, Set<string>>> = {};
        // DataCore 侧
        map.dataset = new Set((await datacore.get("/a/v1/raw-datasets", tenantId)).map((d: any) => d.name));
        map.ontology_type = new Set((await datacore.get("/a/v1/object-types", tenantId)).map((t: any) => t.key));
        map.rule = new Set((await datacore.get("/a/v1/rules", tenantId)).map((r: any) => r.key));
        map.solver = new Set((await datacore.get("/a/v1/solvers", tenantId)).map((s: any) => s.key));
        // AgentCore 侧
        map.intent = new Set((await agentRepos.intents.list(tenantId)).map((i) => i.key));
        map.plan = new Set((await agentRepos.plans.list(tenantId)).map((p) => p.key));
        map.workflow = new Set((await agentRepos.workflows.list(tenantId)).map((w) => w.key));
        map.skill = new Set((await agentRepos.skills.list(tenantId)).map((s) => s.key));
        map.agent = new Set((await agentRepos.agents.list(tenantId)).map((a) => a.key));
        map.scene = new Set((await agentRepos.scenes.list(tenantId)).map((s) => s.key));
        map.mcp = new Set((await agentRepos.mcps.list(tenantId)).map((m) => m.serverName));
        return map as Record<ModuleKind, Set<string>>;
      }
    },
  };
}
```

**缓存策略**：
- 不依赖后端事件总线（不存在）。
- AgentCore 在内存中缓存 `snapshot()` 结果，TTL 60 秒。
- 前端收到任何 `{kind}.updated` 事件时，在请求头中附加 `X-Registry-Invalidate: 1`，后端看到该头时跳过缓存。
- 这是一个**请求级失效**机制，不是 pub/sub，但足够有效。

### 4.2 统一 diff 引擎：`analyzeGap` 的扩展

现有 `analyzeGap(deps, ctx, plan, scaffoldReceipt?)` 只接受 `BuildPlan`。  
v3 扩展为同时接受 `QueryRequirementTree`：

```typescript
// apps/datacore/src/databuilder/provisioners.ts

/** Query 目标推导出的需求树。
 * v3 Phase 1 先用轻量规则/模板匹配（确定性、低延迟），但接口预留 LLM 推导插槽。
 * 若上线后轻量匹配的 Top-3 召回率 < 80%，可无痛切换为 LLM 推导（不改动契约）。
 */
export interface IntentAnalyzer {
  // 轻量匹配实现（Phase 1）
  // RG Engine Ch2 六维提取：Intent + Entity + Action + Constraint + Temporal + Business Goal
  classify(query: string, opts?: { base?: string; segment?: string }): Promise<{
    objectTypes: string[];         // Entity Extraction
    suggestedSolvers: string[];    // Intent → Solver Mapping
    matchedIntents: string[];      // Intent Extraction
    actions: string[];             // Action Extraction（新增）
    constraints: string[];         // Constraint Extraction（新增）
    temporals: string[];           // Temporal Expression Extraction（新增）
    businessGoals: string[];       // Business Goal Extraction（新增）
  }>;
  // 预留：LLM 推导实现（Phase 3 或后续迭代，数据驱动决策）
  // classifyWithLlm?(query: string, opts?: { base?: string; segment?: string }): Promise<...>;
}

/** 轻量 Ontology 扩展规则（隐藏需求发现 v1）
 * RG Engine Ch5.9：用户显式提到的需求只是冰山一角，系统必须根据 Ontology 关系推导隐藏需求。
 * v3 不实现完整 Graph Rewrite，而是用可配置的轻量规则做一级扩展。
 */
export interface HiddenRequirementRule {
  id: string;
  when: { objectTypes: string[] };          // 当需求树包含这些对象类型时触发
  add: { objectTypes?: string[]; solvers?: string[]; datasets?: string[] };
  rationale: string;                         // 为什么追加（用于 explanation）
}

export const DEFAULT_HIDDEN_RULES: HiddenRequirementRule[] = [
  {
    id: "HIDDEN_ORDER_IMPACT_001",
    when: { objectTypes: ["order"] },
    add: { objectTypes: ["production_line", "inventory", "capacity"], datasets: ["capacity_snapshots"] },
    rationale: "订单影响分析必须知道产能、库存和产线状态",
  },
  {
    id: "HIDDEN_FACTORY_SHUTDOWN_001",
    when: { objectTypes: ["factory"], actions: ["shutdown"] },
    add: { objectTypes: ["equipment", "material", "logistics_route"], solvers: ["capacity_loss"] },
    rationale: "工厂停产事件必须检查设备状态、原材料和物流能力",
  },
];

export interface QueryRequirementTree {
  kind: "query";
  query: string;
  // 从 query 解析出的意图和所需模块（由 AgentCore 的意图分析器填充）
  requiredObjectTypes: string[];   // 涉及的对象类型（显式 + 隐藏扩展后）
  requiredSolvers: string[];       // 可能需要的求解器（显式 + 隐藏扩展后）
  requiredIntents: string[];       // 意图 key
  requiredDatasets: string[];      // 数据需求（从对象类型反推）
  // v3 新增：RG Engine Ch2 六维提取的完整维度
  requiredActions: string[];       // Action Extraction
  requiredConstraints: string[];   // Constraint Extraction
  requiredTemporal: string[];      // Temporal Expression Extraction
  requiredBusinessGoals: string[]; // Business Goal Extraction
  // 隐藏需求追溯（用于可解释性）
  hiddenRequirements?: { ruleId: string; added: string[]; rationale: string }[];
}
```
```

export type GapInput = { kind: "script"; plan: BuildPlan; scaffoldReceipt?: ScaffoldReceipt } | { kind: "query"; tree: QueryRequirementTree };

export async function analyzeGap(deps: ProvisionerDeps, ctx: AuthCtx, input: GapInput): Promise<GapAnalysis> {
  const entries: GapAnalysisEntry[] = [];

  for (const prov of MODULE_PROVISIONERS) {
    // ① 推导 planned keys
    let planned: string[];
    if (input.kind === "script") {
      planned = uniq(prov.planned(input.plan));
    } else {
      planned = uniq(queryTreeToPlanned(prov.kind, input.tree));
    }
    if (planned.length === 0) continue;

    // ② 查 existing（复用 provisioner.existing 或 AgentCore 代理）
    let existing: Set<string>;
    if (input.kind === "script" || prov.side !== "cross_system") {
      existing = await (prov.existing ?? async () => new Set())(deps, ctx);
    } else {
      // query 目标且 cross_system：由 AgentCore 侧在调用 analyzeGap 前把 existing 注入
      existing = input.tree.agentSideExisting?.[prov.kind] ?? new Set();
    }

    // ③ diff（现有逻辑不变）
    let items: GapItem[];
    if (input.kind === "script" && prov.side === "cross_system" && input.scaffoldReceipt) {
      // 复用现有 scaffoldReceipt 逻辑
      items = planned.map((key) => { ... });
    } else {
      items = planned.map((key) => ({
        key,
        status: existing.has(key) ? "EXISTS" : prov.autoCreatable ? "TO_CREATE" : "MISSING",
      }));
    }

    // v3 新增：填充 severity / rootCause / remediation / explanation
    items = items.map((it) => enrichGapItem(it, prov, input));

    entries.push({ kind: prov.kind, side: prov.side, needed, existing, toCreate, missing, items });
  }

  const analysis: GapAnalysis = { target: inputToTarget(input), entries, totals: computeTotals(entries), generatedAt: new Date().toISOString() };

  // v3 新增：依赖排序生成 ExecutionPlan + Coverage Score
  analysis.executionPlan = buildExecutionPlan(entries);
  analysis.totals.coverageScore = computeCoverageScore(entries);
  return analysis;
}
```

**默认策略映射（`enrichGapItem`）**：

| kind | side | status | strategy | estimatedEffort | severity | 原因 |
|---|---|---|---|---|---|---|
| dataset | content | TO_CREATE | MANUAL | MINUTES | WARNING | 数据导入需人工确认 |
| ontology_type | structure | TO_CREATE | AUTO | SECONDS | WARNING | 本体类型可自动 scaffold |
| rule | structure | TO_CREATE | AUTO_WITH_APPROVAL | MINUTES | WARNING | 规则需审批发布 |
| solver | code | MISSING | DEVELOP | DAYS | **BLOCKER** | 求解器是代码，缺则不可执行 |
| intent | cross_system | TO_CREATE | AUTO_WITH_APPROVAL | SECONDS | ERROR | 意图脚手架+审批 |
| workflow | cross_system | TO_CREATE | AUTO_WITH_APPROVAL | MINUTES | ERROR | 工作流脚手架+审批 |
| kb_doc | content | MISSING | MANUAL | MINUTES | INFO | 知识库文档缺失，可降低准确率 |

**Coverage Score 计算（`computeCoverageScore`）**：

```typescript
function computeCoverageScore(entries: GapAnalysisEntry[]): number {
  // 按 side 加权：code（求解器）最关键，content 次之
  const weights: Record<Side, number> = { content: 0.2, structure: 0.3, code: 0.4, cross_system: 0.1 };
  let totalWeight = 0;
  let coveredWeight = 0;
  for (const e of entries) {
    const w = weights[e.side] ?? 0.1;
    totalWeight += w;
    const coverage = e.needed > 0 ? e.existing / e.needed : 1;
    coveredWeight += w * coverage;
  }
  return totalWeight > 0 ? coveredWeight / totalWeight : 1;
}
```

- **< 0.5**：严重缺口，不可执行（BLOCKER 级缺失）
- **0.5 ~ 0.8**：关键缺口，补完后可执行（ERROR/WARNING 级缺失）
- **> 0.8**：基本可执行，INFO 级建议

**Explanation 填充（`enrichGapItem`）**：

```typescript
function enrichGapItem(item: GapItem, prov: ModuleProvisioner, input: GapInput): GapItem {
  const base = { ...item };
  // severity（基于 kind + status 默认映射）
  if (item.status === "MISSING" && prov.kind === "solver") base.severity = "BLOCKER";
  else if (item.status === "MISSING") base.severity = "ERROR";
  else if (item.status === "TO_CREATE" && prov.side === "code") base.severity = "ERROR";
  else if (item.status === "TO_CREATE") base.severity = "WARNING";
  else base.severity = "INFO";

  // explanation（基于 input 类型生成）
  if (input.kind === "query") {
    const hidden = input.tree.hiddenRequirements?.find((h) => h.added.includes(item.key));
    if (hidden) {
      base.explanation = {
        why: `决策分析需要 ${item.key}（由隐藏需求规则 ${hidden.ruleId} 推导）`,
        evidence: hidden.rationale,
        alternative: prov.kind === "solver" ? undefined : `可暂时跳过，但会降低分析完整性`,
      };
    } else {
      base.explanation = {
        why: `查询意图需要 ${prov.kind} 类型的 ${item.key}`,
        evidence: `意图分析器识别到 ${input.tree.matchedIntents.join(", ") || "未知意图"}`,
      };
    }
  }
  // ... rootCause / remediation 填充（同前）
  return base;
}
```

### 4.3 依赖排序：`buildExecutionPlan`

不需要复杂的图算法。`MODULE_PROVISIONERS` 的 `side` 字段已经定义了依赖方向：

```
content（数据） → structure（本体/规则/切片） → code（求解器） → cross_system（意图/工作流/...）
```

这个顺序是系统架构的天然依赖方向：
- 求解器依赖本体类型和数据
- 工作流依赖求解器和意图
- 意图依赖求解器

```typescript
function buildExecutionPlan(entries: GapAnalysisEntry[]): ExecutionStep[] {
  const sideOrder = ["content", "structure", "code", "cross_system"];
  const nonEmptyEntries = entries.filter((e) => e.items.some((it) => it.status !== "EXISTS"));
  const bySide = groupBy(nonEmptyEntries, (e) => e.side);

  const steps: ExecutionStep[] = [];
  let stepNum = 1;
  for (const side of sideOrder) {
    const sideEntries = bySide.get(side) ?? [];
    const keys = sideEntries.flatMap((e) => e.items.filter((it) => it.status !== "EXISTS").map((it) => it.key));
    if (keys.length === 0) continue;
    steps.push({ step: stepNum++, entries: keys, rationale: `先补齐 ${side} 层（${keys.length} 项）` });
  }
  return steps;
}
```

> **为什么不计算细粒度 prerequisites？**  
> 因为 `prerequisites` 在 v2 中定义为 GapEntry refs 级别的精细依赖。但在现有系统中，模块级别的 side 顺序已经能覆盖 90% 的真实场景。细粒度依赖（如"求解器 A 依赖数据集 B"）需要从求解器的 `ioContract` 中解析，这需要改造求解器注册表——是一个 P2 优化，不在 v3 的 6 周范围内。

---

## 5. 与 Growth Loop 的集成

### 5.1 异步预分析：`preAnalyzeQuery()`

```typescript
// apps/agentcore/src/growth/pre-analyze.ts

export async function preAnalyzeQuery(
  deps: { registry: CapabilityRegistry; intentAnalyzer: IntentAnalyzer; repos: AgentRepos; hiddenRules?: HiddenRequirementRule[] },
  query: string,
  opts?: { base?: string; segment?: string },
): Promise<PreAnalysisReport> {
  // Step 1: 轻量意图分析（RG Engine Ch2 六维提取）
  const intent = await deps.intentAnalyzer.classify(query, opts);

  // Step 2: 推导需求树（显式需求 + 隐藏需求扩展）
  const explicitObjects = intent.objectTypes;
  const explicitSolvers = intent.suggestedSolvers;
  const explicitDatasets = intent.objectTypes.map((ot) => `${ot}_snapshots`);

  // v3 新增：隐藏需求发现（RG Engine Ch5.9 轻量版）
  const hiddenRules = deps.hiddenRules ?? DEFAULT_HIDDEN_RULES;
  const hiddenAdds: HiddenRequirementRule[] = [];
  for (const rule of hiddenRules) {
    const objectMatch = rule.when.objectTypes.some((ot) => explicitObjects.includes(ot));
    const actionMatch = !rule.when.actions || rule.when.actions.some((a) => intent.actions.includes(a));
    if (objectMatch && actionMatch) {
      hiddenAdds.push(rule);
    }
  }
  const hiddenObjects = hiddenAdds.flatMap((r) => r.add.objectTypes ?? []);
  const hiddenSolvers = hiddenAdds.flatMap((r) => r.add.solvers ?? []);
  const hiddenDatasets = hiddenAdds.flatMap((r) => r.add.datasets ?? []);

  const tree: QueryRequirementTree = {
    kind: "query",
    query,
    requiredObjectTypes: [...new Set([...explicitObjects, ...hiddenObjects])],
    requiredSolvers: [...new Set([...explicitSolvers, ...hiddenSolvers])],
    requiredIntents: intent.matchedIntents,
    requiredDatasets: [...new Set([...explicitDatasets, ...hiddenDatasets])],
    // 六维提取完整字段
    requiredActions: intent.actions,
    requiredConstraints: intent.constraints,
    requiredTemporal: intent.temporals,
    requiredBusinessGoals: intent.businessGoals,
    // 隐藏需求追溯（用于可解释性）
    hiddenRequirements: hiddenAdds.map((h) => ({ ruleId: h.id, added: [...(h.add.objectTypes ?? []), ...(h.add.solvers ?? [])], rationale: h.rationale })),
  };

  // Step 3: 拉 Registry Snapshot
  const snapshot = await deps.registry.snapshot(tenantId);

  // Step 4: 调用统一 analyzeGap
  const gapAnalysis = await datacoreClient.analyzeGap({ kind: "query", tree, agentSideExisting: snapshot });

  // Step 5: 生成报告（增加 Coverage Score）
  const allItems = gapAnalysis.entries.flatMap((e) => e.items);
  const nonExisting = allItems.filter((it) => it.status !== "EXISTS");
  return {
    query,
    taskId: "",
    gapAnalysisId: generateId(),
    status: "DONE",
    summary: {
      totalGaps: nonExisting.length,
      autoFixable: nonExisting.filter((it) => ["AUTO", "AUTO_WITH_APPROVAL"].includes(it.remediation?.strategy ?? "")).length,
      manualRequired: nonExisting.filter((it) => it.remediation?.strategy === "MANUAL").length,
      developRequired: nonExisting.filter((it) => it.remediation?.strategy === "DEVELOP").length,
      estimatedSteps: gapAnalysis.executionPlan?.length ?? 0,
      coverageScore: gapAnalysis.totals.coverageScore ?? 0,
    },
  };
}
    },
  };
}
```

**关键设计：不阻塞 SSE + 预分析驱动默认模式切换**

```typescript
// apps/agentcore/src/growth/scenario-grow.ts —— 修改后的 wiring

export function buildGrowthLoopWiring(deps, a, body, emitDomainEvent, opts): GrowthLoopWiring {
  // v3 新增：启动后台预分析（不 await）
  const preAnalysisPromise = preAnalyzeQuery({ registry, intentAnalyzer, repos }, body.question, { base: body.base, segment: body.segment })
    .then((report) => {
      // 预分析完成后，通过 SSE 事件推给前端
      emitDomainEvent("growth.pre_analysis_done", { taskId: body.taskId, report });
      // 存入 growth-ledger，供 TicketCenter 查询
      return deps.repos.growthLedger.savePreAnalysis(body.taskId, report);
    })
    .catch((err) => {
      // 铁律：不作假。预分析失败不静默忽略，而是记录 FAILED 状态并告警。
      const failedReport: PreAnalysisReport = {
        query: body.question,
        taskId: body.taskId,
        gapAnalysisId: generateId(),
        status: "FAILED",
        summary: { totalGaps: 0, autoFixable: 0, manualRequired: 0, developRequired: 0, estimatedSteps: 0 },
      };
      emitDomainEvent("growth.pre_analysis_failed", { taskId: body.taskId, error: err.message });
      deps.repos.growthLedger.savePreAnalysis(body.taskId, failedReport);
      deps.logger.error({ taskId: body.taskId, err }, "preAnalyzeQuery failed");
    });

  const probe = async (): Promise<GapReport> => {
    // 原逻辑不变：提交 QOS 查询 → 轮询 → classifyGap
    const { taskId } = await deps.orchestrator.submitQuery(a, body, undefined, { internal: true });
    // ...
    return classifyGap(task);
  };

  // v3 新增：fill 时检查是否有预分析结果，优先按 ExecutionPlan 系统性补齐
  const fill = async (gap: GapFinding): Promise<GrowthFillResult> => {
    const pre = await deps.repos.growthLedger.getPreAnalysis(body.taskId);
    if (pre?.status === "DONE" && pre.summary.developRequired + pre.summary.manualRequired > 0) {
      // 有非 AUTO 缺口 → 生成 systematic fill 工单，不再 reactive 撞墙
      return { gapCode: gap.gapCode, action: "SYSTEMATIC_FILL", needsHuman: true, worklistItemId: createUnifiedWorkOrder(pre, gap) };
    }
    // 否则走原有 reactive fill
    return originalFill(gap);
  };

  // fill 逻辑不变
}
```

**前端体验（v3 修正：系统默认走 systematic fill，用户可覆盖）**：
1. 用户提问 → QOS 立即返回 SSE stream → 前端开始显示"思考中...”。
2. 几秒后，SSE 收到 `growth.pre_analysis_done` 事件 → 前端在 GapCard 中显示："系统诊断发现 4 项缺口（2 项需人工/开发）。已按依赖顺序生成补齐计划。"
3. **系统默认行为**：按 ExecutionPlan 自动执行 AUTO 项，MANUAL/DEVELOP 项生成工单 → 用户进入 TicketCenter 认领。
4. **用户覆盖选项**：GapCard 提供"忽略诊断，继续尝试回答"按钮 → 回到原有 reactive loop。
5. **预分析失败**：GapCard 显示"系统诊断暂时不可用" + "重试"按钮，QOS 回答继续跑，不阻塞用户。

### 5.2 与 DataBuilder 的集成

DataBuilder 已经调用 `analyzeGap()`。v3 改动最小：

```typescript
// apps/datacore/src/databuilder/service.ts —— run() 方法中

// Phase ③：gap（已有）
const gapAnalysis = await analyzeGap(deps, ctx, { kind: "script", plan, scaffoldReceipt });

// v3 新增：把 target 和 executionPlan 填充进去（analyzeGap 已自动填充）
// gapAnalysis.target = { kind: "script", script: plan.body };

// Phase ④~⑥：按 executionPlan 的顺序执行（如果启用）
// 注：DataBuilder 的 7 阶段管线比 executionPlan 更复杂（有 intake/comprehend/transform），
// 所以 executionPlan 在 DataBuilder 中仅作为"参考顺序"展示给用户，不替换原有管线。
```

---

## 6. 后端接口变更

### 6.1 DataCore 新增端点

```
GET /a/v1/registry/snapshot
Response: Record<ModuleKind, string[]>  // 全局 Registry 聚合快照
```

**为什么必须新增这个端点（全局最优）**：
- 如果不新增，AgentCore 需要调用 10+ 个分散端点才能拼出全景。
- 新增后，所有未来消费者（场景生长、沙盘预检查、验证页）都能复用同一快照。
- 内部实现复用 `MODULE_PROVISIONERS`，1 天工作量。

```
POST /a/v1/databuilder/gap
Body: { kind: "query", tree: QueryRequirementTree } | { kind: "script", plan: BuildPlan, scaffoldReceipt?: ... }
Response: GapAnalysis（扩展后的统一格式）
```

这个端点复用现有的 `analyzeGap()` 函数，只是把它暴露为 HTTP API，供 AgentCore 调用。

### 6.2 AgentCore 新增端点

```
GET /b/v1/growth/pre-analysis/:taskId
Response: PreAnalysisReport
```

供 TicketCenterPage 查询某次查询的预分析结果。

---

## 7. 前端集成

### 7.1 GapCard 改造

当前 GapCard（`apps/frontend-shell/src/components/Answer/GapCard.tsx`）：
- 显示单 finding → 点击 trigger 直接补齐。

v3 改造（诚实、不静默失败）：
- **预分析成功且有 MANUAL/DEVELOP 缺口** → 显示：
  - 头部：`系统覆盖率 {coverageScore}% · {totalGaps} 项缺口 · {autoFixable} 项可自动补`
  - 若 coverageScore < 50%：红色警告"严重缺口，不可执行"
  - 若 coverageScore < 80%：琥珀色警告"关键缺口，补完后可执行"
  - 按钮 1："查看工单" → 深链到 TicketCenter (`/admin/tickets?taskId=xxx`)
  - 按钮 2："忽略诊断，继续尝试回答" → 走原有 reactive loop（用户覆盖权）
- **预分析成功且全 AUTO** → 显示："系统覆盖率 {coverageScore}% · 全部可自动补齐" → 按钮"一键补齐"
- **预分析还在跑** → 显示加载状态"系统诊断中..."，不影响 reactive loop。
- **预分析失败** → 显示："系统诊断暂时不可用" + "重试"按钮（诚实暴露问题，不假装一切正常）。QOS 回答继续跑，不阻塞用户。

### 7.2 TicketCenterPage 增强

当前 TicketCenter 展示 WorklistItem 列表。v3 增强：

1. **新增"诊断新缺口"流程**：输入查询 → 调用 `preAnalyzeQuery` → 展示 `GapAnalysis` 全景 → 确认后生成工单。
2. **工单行增强**：
   - 显示"本查询涉及 N 项缺口，这是第 X 项"
   - **Severity 徽章**：BLOCKER=红 / ERROR=红 / WARNING=琥珀 / INFO=蓝
   - **可解释性展开**：点击缺口行展开 `explanation.why` + `explanation.evidence` + `explanation.alternative`
   - 显示 ExecutionPlan 步骤图（当前在第几步）
   - 显示依赖关系（前置条件是否满足）
3. **快捷执行**：`strategy: "AUTO"` 且 `estimatedEffort: "SECONDS"` 且 `severity !== "BLOCKER"` 的缺口，允许在工单页直接点击"自动补齐"。
4. **Coverage Score 头部**：工单详情页顶部显示进度环，直观展示当前覆盖率。

---

## 8. 实施计划（8 周，分 3 个 Phase）

### Phase 1：统一契约 + Query 目标支持 + Registry 全局端点 + 隐藏需求发现（3 周）

**后端**：
- [ ] 扩展 `packages/contracts/src/databuilder.ts`：`GapTargetSchema`、`GapRootCauseSchema`、`GapRemediationSchema`、`ExecutionStepSchema`、`GapSeveritySchema`、`GapExplanationSchema`
- [ ] 扩展 `packages/contracts/src/growth.ts`：`PreAnalysisReportSchema`（增加 `coverageScore`）
- [ ] DataCore 新增 `GET /a/v1/registry/snapshot` 端点（全局基础设施，所有消费者复用）
- [ ] DataCore 新增 `POST /a/v1/databuilder/gap` 端点（复用现有 `analyzeGap`）
- [ ] 扩展 `analyzeGap()` 支持 `QueryRequirementTree` 输入（含六维提取 + 隐藏需求）
- [ ] 实现 `enrichGapItem()` 默认策略映射（含 Severity + Explanation）
- [ ] 实现 `buildExecutionPlan()` 依赖排序
- [ ] 实现 `computeCoverageScore()` 覆盖率算法
- [ ] `IntentAnalyzer` 接口设计（六维提取 + 预留 LLM 插槽）
- [ ] **隐藏需求发现**：实现 `DEFAULT_HIDDEN_RULES` 轻量 Ontology 扩展规则（可配置、可覆盖）

**前端**：
- [ ] TicketCenter 新增"诊断新缺口"流程（输入查询 → 展示 GapAnalysis 全景 + Coverage Score）
- [ ] GapCard / TicketCenter 展示 Severity 徽章（BLOCKER/ERROR/WARNING/INFO）
- [ ] GapCard / TicketCenter 展示 Explanation（Why / Evidence / Alternative）

### Phase 2：异步预分析 + 预分析驱动默认模式切换（3 周）

**后端**：
- [ ] AgentCore 实现 `createHttpCapabilityRegistry()`（优先 snapshot，fallback 分散端点）
- [ ] 实现 `preAnalyzeQuery()`（六维意图分析 + 隐藏需求扩展 + Registry snapshot + 调用 DataCore gap）
- [ ] **核心**：修改 `buildGrowthLoopWiring()`：
  - 启动后台 `preAnalysisPromise`（不阻塞 SSE）
  - 预分析成功且有 MANUAL/DEVELOP 缺口时，`fill()` 默认走 systematic fill（生成工单），不再 reactive 撞墙
  - 用户可通过前端按钮覆盖回 reactive loop
- [ ] 预分析失败处理：记录 `FAILED` 状态、emit SSE 事件、打 ERROR 日志
- [ ] AgentCore 新增 `GET /b/v1/growth/pre-analysis/:taskId`
- [ ] `GrowthLedger` repo 扩展存储 `PreAnalysisReport`

**前端**：
- [ ] GapCard 改造：显示 Coverage Score + 预分析摘要 + "查看工单"按钮 + "忽略诊断，继续尝试回答"按钮
- [ ] GapCard 预分析失败态："系统诊断暂时不可用" + "重试"按钮
- [ ] TicketCenter 工单行展示 ExecutionPlan 步骤图 + Severity 徽章 + Explanation 展开
- [ ] 工单详情页顶部显示 Coverage Score 进度环

### Phase 3：补齐验证统一 + 影响分析 P1 + 数据驱动升级决策（2 周）

**后端**：
- [ ] 统一补齐后验证：所有补齐完成后自动跑一次轻量 QOS probe（复用 `verifyBuild()` 模式）
- [ ] 实现影响分析 v1（基于 `downstream` 字段的简单标记）
- [ ] **数据收集**：统计轻量意图匹配的六维召回率，统计 Coverage Score 与实际可执行性的相关性
- [ ] **决策**：若轻量匹配 Top-3 召回率 < 80% 或 Coverage Score 与实际可执行性偏差 > 20%，启动 LLM 推导升级

**前端**：
- [ ] 工单页面展示影响分析
- [ ] 连接维度/数据集维度页面执行操作后自动生成追溯工单（只读）
- [ ] 管理后台新增"隐藏需求规则"配置页面（可增删改 `HiddenRequirementRule`）

---

## 9. 风险与回滚策略

| 风险 | 缓解措施 |
|---|---|
| `preAnalyzeQuery` 意图分析不准确 | **数据驱动升级**：Phase 1 预留 LLM 插槽，Phase 3 收集六维召回率数据，Top-3 召回率 < 80% 时升级。不准确时用户仍可覆盖回 reactive loop。 |
| **隐藏需求规则过度扩展**（RG Engine 审计发现） | 规则可配置、可覆盖；管理后台提供规则开关；前端 GapCard 标注"由隐藏需求规则推导"，用户可选择忽略单个隐藏需求 |
| **Coverage Score 与实际可执行性偏差** | Phase 3 收集 Coverage Score 与实际 QOS 执行成功率的相关性数据，动态调整权重 |
| AgentCore → DataCore 内部 HTTP 调用增加延迟 | Registry snapshot 可缓存 60s；`GET /a/v1/registry/snapshot` 单次调用替代 10+ 分散调用；预分析是后台异步，不影响主路径 |
| 扩展 `GapItemSchema` 导致旧数据反序列化失败 | 所有新增字段都是 `optional()`，zod 会忽略缺失字段 |
| DataBuilder 7 阶段管线与 ExecutionPlan 冲突 | ExecutionPlan 在 DataBuilder 中仅展示，不替换管线控制流 |
| 预分析失败被静默忽略（违反铁律） | **已修正**：失败时记录 `FAILED` 状态、emit SSE 事件、打 ERROR 日志，GapCard 显示"暂时不可用" |
| 用户不习惯 systematic fill 默认行为 | 提供显式"忽略诊断，继续尝试回答"按钮，保留用户选择权；通过工单完成率数据验证新体验是否优于 reactive loop |
| 8 周做不完 | Phase 1 完成后即可交付"统一契约 + 隐藏需求发现"价值；Phase 2 是核心体验升级；Phase 3 是数据驱动优化 |

**回滚**：
- 若需回滚，将 `fill()` 中的 systematic fill 分支改为可选（feature flag），默认关闭即可恢复纯 reactive loop。
- `classifyGap()` 和 `runGrowthLoop()` 原逻辑未被修改，仅新增分支。
- `GapAnalysis` 扩展字段都是 optional，旧代码不读它们即可。
- 隐藏需求规则可通过管理后台一键关闭，回退到纯显式需求分析。

---

## 10. 已确认决策（按铁律重新审视后）

1. **QueryRequirementTree 的推导方式**：Phase 1 先用轻量规则/模板匹配（确定性、低延迟），但 `IntentAnalyzer` 接口预留 LLM 推导插槽。Phase 3 收集准确率数据，若 Top-3 召回率 < 80%，升级至 LLM 推导。**不作假**：PRD 已标注轻量匹配的局限性。

2. **AgentCore 对 DataCore 的内部调用**：DataCore 新增 `GET /a/v1/registry/snapshot` 统一端点（全局基础设施）。AgentCore `CapabilityRegistry` 优先调用 snapshot，fallback 到分散端点。**不图省事**：不满足于复用现有分散调用。

3. **预分析失败的处理**：**不静默忽略**。失败时：① GapCard 显示"系统诊断暂时不可用" + "重试"按钮；② 向 growth-ledger 写入 `status: "FAILED"`；③ emit SSE 事件 `growth.pre_analysis_failed`；④ 打 ERROR 级日志。**不作假、不偷懒**。

4. **Phase 2 核心不是"展示按钮"而是"默认行为切换"**：当预分析发现 MANUAL/DEVELOP 缺口时，`fill()` 默认走 systematic fill（按 ExecutionPlan 生成工单），不再 reactive 撞墙。用户有覆盖权（"忽略诊断，继续尝试回答"），但系统默认行为已经解决根本问题。**不局部最优**。

5. **隐藏需求发现必须纳入**（RG Engine Ch5.9 审计发现）：PRD v3 原始设计只映射显式需求，导致诊断不完整。修正后：实现轻量 `HiddenRequirementRule`（可配置、可覆盖），按 Ontology 关系自动扩展隐藏需求（Order→BOM→Material→Supplier）。**不图省事**。

6. **Question AST 必须六维提取**（RG Engine Ch2 审计发现）：原始设计只提取 Intent/Entity/Solver 三维，遗漏 Action/Constraint/Temporal/Business Goal。修正后：`IntentAnalyzer.classify()` 返回六维字段，`QueryRequirementTree` 扩展 `requiredActions` / `requiredConstraints` / `requiredTemporal` / `requiredBusinessGoals`。**不作假**。

7. **Coverage Score 量化可执行性必须纳入**（RG Engine Ch9.10 审计发现）：原始设计只有 `needed/existing/toCreate/missing` 计数，无法判断"补完能否执行"。修正后：`GapAnalysis.totals` 增加 `coverageScore`（0~1，按 side 加权计算），前端显示进度环。

8. **Severity 分级 + 可解释性必须纳入**（RG Engine Ch9.13 + Ch11 审计发现）：原始设计所有缺口一视同仁。修正后：`GapItem` 增加 `severity`（INFO/WARNING/ERROR/BLOCKER）和 `explanation`（Why/Evidence/Alternative），前端用徽章颜色和展开面板展示。**不偷懒**。

确认后进入详细设计和开发。

---

## 附录 A：v2 → v3 决策对照表

| v2 设计 | v3 决策 | 原因 |
|---|---|---|
| 新建 7-Layer Graph Validator | **复用 `ClosureReport` + `selfcheck.ts`** | 现有验证已覆盖 5 维度，新增图验证需要 2 个月 |
| 新建完整 Graph Rewrite Engine | **轻量 `HiddenRequirementRule`（可配置规则）** | RG Engine Ch5.9 要求隐藏需求发现，但完整 GRE 需要 2 个月；轻量规则 3 天可交付 80% 价值 |
| 新建 Coverage Score（乘积公式） | **`GapAnalysis.totals.coverageScore`（加权求和）** | 乘积公式过于敏感（一个 0 导致整体 0）；加权求和更符合工业场景 |
| 常驻 Redis Registry + 事件失效 | **按需 HTTP 聚合 + 请求级缓存** | 后端没有事件总线，Redis 是新增基础设施 |
| PRE_ANALYSIS 阻塞 submitQuery | **后台异步预分析** | 阻塞会杀死 SSE 实时体验 |
| 细粒度 prerequisites 图排序 | **side 级拓扑排序（4 层）** | 覆盖 90% 场景，细粒度需要求解器 ioContract 解析 |
| 3 目标类型同时支持（query/script/scenario） | **先做 query + script，scenario 延后** | scenario 需要场景解析器，复杂度与 script 同级 |
| 7 周分 4 个 Phase | **8 周分 3 个 Phase** | RG Engine 审计后增加隐藏需求发现 + Coverage Score + Severity + Explanation，Phase 1 增加 1 周 |

## 附录 B：关键文件索引

| 文件 | v3 中的作用 |
|---|---|
| `packages/contracts/src/databuilder.ts` | 扩展 `GapAnalysis` 统一契约（含 Severity / Explanation / CoverageScore） |
| `packages/contracts/src/growth.ts` | 新增 `PreAnalysisReport`（含 coverageScore） |
| `apps/datacore/src/databuilder/provisioners.ts` | 扩展 `analyzeGap` 支持 query 目标（六维提取 + 隐藏需求）；新增 `enrichGapItem`、`buildExecutionPlan`、`computeCoverageScore`、`HiddenRequirementRule` |
| `apps/datacore/src/databuilder/service.ts` | DataBuilder 调用 analyzeGap 处适配新签名（最小改动） |
| `apps/datacore/src/databuilder/provisioners.ts` | **新增**：`GET /a/v1/registry/snapshot` 端点实现 |
| `apps/agentcore/src/growth/pre-analyze.ts` | **新增**：异步预分析实现（六维意图分析 + 隐藏需求扩展） |
| `apps/agentcore/src/growth/capability-registry.ts` | **新增**：按需 Registry 聚合查询（优先 snapshot） |
| `apps/agentcore/src/growth/scenario-grow.ts` | 修改 `buildGrowthLoopWiring` 启动后台预分析 + 默认 systematic fill |
| `apps/agentcore/src/growth/probe.ts` | **不修改**：`classifyGap` 保持单发现设计 |
| `apps/frontend-shell/src/components/Answer/GapCard.tsx` | 改造：显示 Coverage Score + Severity + 预分析摘要 + "查看工单" |
| `apps/frontend-shell/src/pages/admin/TicketCenterPage.tsx` | 增强：展示 ExecutionPlan 步骤图 + Severity 徽章 + Explanation 展开 + Coverage Score 进度环 |
| `apps/frontend-shell/src/pages/admin/HiddenRulesConfigPage.tsx` | **新增**：隐藏需求规则配置页面（管理后台） |
