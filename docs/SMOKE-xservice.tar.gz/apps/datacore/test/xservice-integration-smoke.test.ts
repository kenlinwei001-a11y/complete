import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { makeApp, seedBattery, type TestApp } from "./helpers.js";
// 跨包导入：AgentCore 真实 HTTP DataCore 客户端（与生产同一份代码路径）。
import { createHttpDataCore } from "../../agentcore/src/tools/datacore-http.js";
import type { DataCoreClient, ToolAuthCtx } from "../../agentcore/src/tools/clients.js";

/**
 * 跨服务真实联调冒烟：起真实 DataCore（监听端口）+ 真实 AgentCore HTTP 求解器客户端，
 * 走真实 fetch → /a/v1/solvers/{key}/invoke → DataCore 求解器 → 种子数据，验证：
 *  ① 序列化/反序列化 + OBO 鉴权头透传（x-debug-user URI 编解码）链路通；
 *  ② 13 个新求解器经真实 HTTP 可解析（无 SOLVER_NOT_FOUND / FEATURE_NOT_FOUND）；
 *  ③ §7 戏剧点真值跨进程一致（碳超标 / 信用冻结 / 外协节省）。
 */

const ARGS: Record<string, Record<string, unknown>> = {
  capacity_forecast: { modelId: "4680-NCM", qty: 40, weeks: 6 }, // S01
  affected_orders: { baseId: "changzhou", day: 30, peak: 90 }, // S02
  mitigation_select: { baseName: "常州", factor: "物料齐套" }, // S06
  outsourcing_split: { gap: 80000, weeks: 6 }, // S14
  quarterly_gap: { quarter: "2026-Q4" }, // S19
  cert_schedule: { horizonWeeks: 12 }, // S07
  kit_readiness: { fromDay: 1, toDay: 14 }, // S08
  lta_gap: { material: "三元正极", month: "2026-07" }, // S09
  inventory_optimize: {}, // S10
  changeover_sequence: { lineId: "LINE-changzhou", week: 1 }, // S11
  quote_margin: { custName: "电网公司F", modelId: "4680-NCM", qty: 500 }, // S15
  credit_exposure: { custName: "商用车集团G" }, // S16
  carbon_footprint: { modelId: "4680-NCM", baseName: "成都" }, // S20
  yield_diagnosis: { processKey: "涂布", baseName: "常州" }, // S12
};

describe("跨服务真实联调冒烟 — 真实 AgentCore HTTP 客户端 ↔ 真实 DataCore（端口监听）", () => {
  let t: TestApp;
  let baseUrl: string;
  let dc: DataCoreClient;
  const ctx: ToolAuthCtx = { tenantId: "demo", userId: "admin", roles: ["admin"], debugUser: "demo:admin:admin" };

  beforeAll(async () => {
    t = await makeApp();
    await seedBattery(t);
    baseUrl = await t.app.listen({ port: 0, host: "127.0.0.1" }); // 真实端口
    dc = createHttpDataCore(baseUrl);
  });
  afterAll(async () => {
    await t.app.close();
  });

  it("真实端口 + OBO 头透传：起在 127.0.0.1，AgentCore 客户端经 fetch 联通", () => {
    expect(baseUrl).toMatch(/^http:\/\/127\.0\.0\.1:\d+$/);
  });

  it("全部 14 个场景求解器经真实 HTTP 调用 → 返回 {data, snapshotVersion}（含 13 新求解器中 11 个）", async () => {
    for (const [key, args] of Object.entries(ARGS)) {
      const payload = await dc.solver.invoke(ctx, key, args);
      expect(payload.snapshotVersion, key).toBeTruthy();
      expect(payload.data, key).toBeTruthy();
      expect((payload.data as { error?: unknown }).error, key).toBeUndefined();
    }
  });

  it("§7 戏剧点跨进程真值一致：碳超标(成都) / 信用冻结(G) / 外协有节省 / 季度缺口数值", async () => {
    const carbon = (await dc.solver.invoke(ctx, "carbon_footprint", ARGS.carbon_footprint!)).data as { verdict: string; total: number };
    expect(carbon.verdict).toBe("超标");
    const credit = (await dc.solver.invoke(ctx, "credit_exposure", ARGS.credit_exposure!)).data as { frozen: boolean; overdueList: unknown[] };
    expect(credit.frozen).toBe(true);
    expect(credit.overdueList.length).toBeGreaterThan(0);
    const outs = (await dc.solver.invoke(ctx, "outsourcing_split", ARGS.outsourcing_split!)).data as { savings: number };
    expect(outs.savings).toBeGreaterThan(0);
    const cert = (await dc.solver.invoke(ctx, "cert_schedule", ARGS.cert_schedule!)).data as { schedule: unknown[] };
    expect(Array.isArray(cert.schedule)).toBe(true);
  });

  it("跨服务错误信封透传：未知求解器 → DataCoreHttpError（404/错误码），不静默吞", async () => {
    await expect(dc.solver.invoke(ctx, "no_such_solver", {})).rejects.toMatchObject({ statusCode: 404, code: "NOT_FOUND" });
  });

  it("行级策略跨进程生效：base_manager:常州 经 OBO 头 → affected_orders 仅见常州单", async () => {
    const czCtx: ToolAuthCtx = { tenantId: "demo", userId: "user-cz", roles: ["base_manager:常州"], debugUser: "demo:user-cz:base_manager:常州" };
    const all = (await dc.solver.invoke(ctx, "affected_orders", { baseId: "changzhou", day: 30, peak: 90 })).data as { affected: { base?: string }[] };
    const cz = (await dc.solver.invoke(czCtx, "affected_orders", { baseId: "changzhou", day: 30, peak: 90 })).data as { affected: unknown[] };
    // 常州经理可见集 ⊆ 全量；且调用不被拒（OBO 头跨进程解析为受限角色）
    expect(Array.isArray(cz.affected)).toBe(true);
    expect(cz.affected.length).toBeLessThanOrEqual(all.affected.length);
  });
});
